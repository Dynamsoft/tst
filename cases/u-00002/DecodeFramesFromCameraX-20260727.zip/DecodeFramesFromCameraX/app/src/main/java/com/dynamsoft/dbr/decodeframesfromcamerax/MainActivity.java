package com.dynamsoft.dbr.decodeframesfromcamerax;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.MainThread;
import androidx.annotation.WorkerThread;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.dynamsoft.core.basic_structures.ImageData;
import com.dynamsoft.core.basic_structures.Quadrilateral;
import com.dynamsoft.cvr.CapturedResult;
import com.dynamsoft.cvr.CaptureVisionRouter;
import com.dynamsoft.cvr.CaptureVisionRouterException;
import com.dynamsoft.cvr.EnumPresetTemplate;
import com.dynamsoft.dbr.BarcodeResultItem;
import com.dynamsoft.dbr.DecodedBarcodesResult;
import com.dynamsoft.dbr.decodeframesfromcamerax.ui.PreviewWithDrawingQuads;
import com.dynamsoft.dbr.decodeframesfromcamerax.ui.resultsview.CustomizedResultsDisplayView;
import com.dynamsoft.license.LicenseManager;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private CaptureVisionRouter mRouter;
    private PreviewWithDrawingQuads mPreviewWithDrawingQuads;

    // Guards against overlapping capture() calls: CameraX delivers frames from a single-thread
    // executor, but capture() itself can take longer than the frame interval on slower devices.
    private volatile boolean mIsCapturing = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        if (savedInstanceState == null) {
            // Initialize the license.
            // You can request an extension via the following link: https://www.dynamsoft.com/customer/license/trialLicense?product=dbr&utm_source=samples&package=android
            LicenseManager.initLicense("t0068MgAAAHUVKt25LwTl34ATVbSCEdaH5QH4jFx7fAHwH8qfI+IYKOLykOCCkIiBwaVy47n2Ykp2kVZYSri27Irnw88au4c=", (isSuccess, error) -> {
                if (!isSuccess) {
                    error.printStackTrace();
                }
            });
        }
        requestCameraPermission(this);
        mPreviewWithDrawingQuads = findViewById(R.id.previewView);

        mRouter = new CaptureVisionRouter();
        try {
            mRouter.initSettingsFromFile("dcv-mobile-v3.4.1000-22368.json");
        } catch (CaptureVisionRouterException e) {
            throw new RuntimeException(e);
        }

        // Unlike DecodeWithCameraX, we do NOT call mRouter.setInput()/startCapturing().
        // Instead, CameraXFrameCaptureAdapter hands us each analyzed frame as an NV21 ImageData,
        // and we feed it into the router ourselves via CaptureVisionRouter.capture().
        new CameraXFrameCaptureAdapter(this, this, mPreviewWithDrawingQuads, this::onFrameAvailable);
    }

    // Called back on the CameraX analyzer's background thread for every analyzed frame.
    @WorkerThread
    private void onFrameAvailable(ImageData imageData) {
        // Skip this frame if the previous capture() call has not returned yet, so frames don't
        // pile up on the single analyzer thread.
        if (mIsCapturing) {
            return;
        }
        mIsCapturing = true;
        try {
            // capture() runs the whole capture pipeline synchronously on the calling thread and
            // returns the result directly, instead of relying on the CapturedResultReceiver
            // callback used by the SetInput/StartCapturing mechanism.
            CapturedResult capturedResult = mRouter.capture(imageData, EnumPresetTemplate.PT_READ_BARCODES);
            DecodedBarcodesResult result = capturedResult.getDecodedBarcodesResult();

            ArrayList<Quadrilateral> list = new ArrayList<>();
            if (result != null && result.getItems() != null) {
                for (BarcodeResultItem item : result.getItems()) {
                    list.add(item.getLocation());
                }
            }
            // updateQuadsOnBuffer() calls invalidate() on the View, so it must run on the UI thread.
            runOnUiThread(() -> {
                mPreviewWithDrawingQuads.updateQuadsOnBuffer(list);
                showResult(result);
            });
        } finally {
            mIsCapturing = false;
        }
    }

    // This is the method that access all BarcodeResultItem in the DecodedBarcodesResult and extract the content.
    @MainThread
    private void showResult(DecodedBarcodesResult result) {
        if (result != null && result.getItems() != null && result.getItems().length > 0) {
            CustomizedResultsDisplayView resultView = findViewById(R.id.results_view);
            resultView.setVisibility(View.VISIBLE);
            resultView.updateResults(result.getItems());
        }
    }

    public static void requestCameraPermission(Activity activity) {
        try {
            if (ContextCompat.checkSelfPermission(activity, android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.CAMERA}, 1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
