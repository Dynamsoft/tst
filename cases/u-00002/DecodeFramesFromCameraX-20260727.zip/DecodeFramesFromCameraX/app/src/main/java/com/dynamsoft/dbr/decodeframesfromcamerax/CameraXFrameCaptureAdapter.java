package com.dynamsoft.dbr.decodeframesfromcamerax;

import android.content.Context;
import android.content.res.Configuration;
import android.util.Size;

import androidx.camera.view.CameraController;
import androidx.camera.view.LifecycleCameraController;
import androidx.lifecycle.LifecycleOwner;

import com.dynamsoft.core.basic_structures.EnumImagePixelFormat;
import com.dynamsoft.core.basic_structures.ImageData;
import com.dynamsoft.dbr.decodeframesfromcamerax.ui.PreviewWithDrawingQuads;

import java.util.concurrent.Executors;

/**
 * Unlike CameraXImageSourceAdapter in the DecodeWithCameraX sample, this class does NOT extend
 * ImageSourceAdapter and is NOT plugged into the CaptureVisionRouter via setInput().
 * <p>
 * Instead, it directly converts each CameraX ImageAnalysis frame into an NV21 ImageData and hands
 * it to the caller (see OnFrameAvailableListener), so the caller can pass it straight into
 * CaptureVisionRouter.capture(ImageData, String) frame by frame.
 */
public class CameraXFrameCaptureAdapter {
    public static final Size DEFAULT_RESOLUTION_PORTRAIT = new Size(1080, 1920);
    public static final Size DEFAULT_RESOLUTION_LANDSCAPE = new Size(1920, 1080);

    public interface OnFrameAvailableListener {
        void onFrameAvailable(ImageData imageData);
    }

    private byte[] mBytes;

    public CameraXFrameCaptureAdapter(Context context, LifecycleOwner lifecycleOwner, PreviewWithDrawingQuads previewWithDrawingQuads, OnFrameAvailableListener listener) {
        LifecycleCameraController lifecycleCameraController = new LifecycleCameraController(context);
        lifecycleCameraController.bindToLifecycle(lifecycleOwner);
        lifecycleCameraController.setTapToFocusEnabled(true);
        CameraController.OutputSize outputSize;
        if (context.getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            outputSize = new CameraController.OutputSize(DEFAULT_RESOLUTION_LANDSCAPE);
        } else {
            outputSize = new CameraController.OutputSize(DEFAULT_RESOLUTION_PORTRAIT);
        }
        lifecycleCameraController.setPreviewTargetSize(outputSize);
        lifecycleCameraController.setImageAnalysisTargetSize(outputSize);

        lifecycleCameraController.setImageAnalysisAnalyzer(Executors.newSingleThreadExecutor(), image -> {
            previewWithDrawingQuads.updateBufferToSensorTransformMatrix(image.getImageInfo());
            try {
                if (mBytes == null || mBytes.length != image.getPlanes()[0].getBuffer().remaining()) {
                    mBytes = new byte[image.getPlanes()[0].getBuffer().remaining()];
                }
                image.getPlanes()[0].getBuffer().get(mBytes);
                int nRowStride = image.getPlanes()[0].getRowStride();
                ImageData imageData = new ImageData();
                imageData.bytes = mBytes;
                imageData.width = image.getWidth();
                imageData.height = image.getHeight();
                imageData.stride = nRowStride;
                imageData.format = EnumImagePixelFormat.IPF_NV21;
                // Directly hand the frame to the caller so it can call CaptureVisionRouter.capture()
                // on this analyzer thread, instead of buffering it through an ImageSourceAdapter.
                listener.onFrameAvailable(imageData);
            } finally {
                image.close();
            }
        });
        previewWithDrawingQuads.previewView.setController(lifecycleCameraController);
    }
}
