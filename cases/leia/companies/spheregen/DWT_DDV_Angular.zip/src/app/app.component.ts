import { Component, OnInit, HostListener } from '@angular/core';
import { Subject } from 'rxjs';
import { FormsModule } from '@angular/forms';
import { DDVAppComponent } from './components/ddv.component';

@Component({
  imports: [
    FormsModule,
    DDVAppComponent
  ],
  selector: 'app-root',
  templateUrl: './app.component.html',
  standalone: true
})
export class AppComponent implements OnInit {
  eventsSubject: Subject<void> = new Subject<void>();

  @HostListener('window:resize', ['$event'])
  onResize(event: any) {
    this.eventsSubject.next(event);
  }
  
  constructor() {
  }

  ngOnInit() {
  }

}
