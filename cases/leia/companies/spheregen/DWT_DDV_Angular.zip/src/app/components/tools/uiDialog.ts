import {tools} from './tools'
import { $, simpleJQ } from "./simpleJQ"
import { Dynamsoft_Ref } from '../../../globalObjects';

let lib:any = Dynamsoft_Ref.Lib;

const UI = {

  install : {
    _dlgInstall: null
  },
  CloseMessage: function () {

    let dlgInstall:any = UI.install._dlgInstall;
    if (dlgInstall) {

      let aryClose = document.querySelectorAll('.ds-ui-dlg-close');
      tools.each(aryClose, function (o, n) {
        tools.removeEventListener(o, 'click', UI.CloseMessage);
      });

      if (dlgInstall.open)
        dlgInstall.close();

      document.body.removeChild(dlgInstall);

      UI.install._dlgInstall = false;
    }
  },
  ShowMessage : function (divContent, dlgConfigs) {

    let install = UI.install,
      dlgClass = 'ds-ui-dlg',
      dlgWrapClass = 'ds-ui-dlg-wrap',
      bReadyClosed = true,
      _dialogWidth, _dialogHeight, _seconds = 0,
      bClose = true,
      bAutoClose,
      divClose, divCloseTimer,
      bFirstShow = true,
      wrapHeaderStyle = 0,
      position = 'fixed',
      caption = 'Error',
      darkBackground = false,
      onClose:any = null;

    if (dlgConfigs) {
      _dialogWidth = dlgConfigs.width;
      _dialogHeight = dlgConfigs.height;
      if (dlgConfigs.seconds) {
        _seconds = dlgConfigs.seconds;
      }

      if (dlgConfigs.headerStyle) {
        wrapHeaderStyle = dlgConfigs.headerStyle;
      }

      if (dlgConfigs.backgroundStyle == 1) {
        darkBackground = true;
      }

      if (dlgConfigs.closeButton === false) {
        bClose = false;
      }


      if (dlgConfigs.bAutoClose) {
        bAutoClose = dlgConfigs.bAutoClose;
        bClose = true;
      }

      if (dlgConfigs.bReadyClosed == false) {
        bReadyClosed = false;
      }

      if (dlgConfigs.position) {
        position = dlgConfigs.position;
      }

      if (dlgConfigs.caption) {
        caption = dlgConfigs.caption;
      }

      if (tools.isFunction(dlgConfigs.onClose)) {
        onClose = dlgConfigs.onClose;
      }
    }

    if (!_dialogHeight)
      _dialogHeight = '100%';

    if (wrapHeaderStyle == 0) {

      if(tools.isString(divContent)) {
        divContent = ['<div>',
          '<div class="ds-ui-dlg-header">',
          '<div class="ds-ui-dlg-caption">', caption, '</div>',
          bClose ? '<div class="ds-ui-dlg-close"></div>' : '',
          '</div>',
          '<div class="ds-ui-dlg-body">',
          divContent,
          '</div></div>'
        ].join('');
      }

    }

    if (!document.querySelector('.' + dlgClass)) {

      let p = document.createElement('div'),
        wrap = document.createElement('div'),
        wrap2 = document.createElement('div');

      p.className = dlgClass;

      wrap.className = dlgWrapClass;
      wrap.style.zIndex = '9999';

      if (bAutoClose) {
        divClose = document.createElement('div');
        divClose.className = 'ds-ui-dlg-close';
        wrap.insertBefore(divClose, wrap.firstElementChild);

        divCloseTimer = document.createElement('div');
        divCloseTimer.className = 'ds-ui-dlg-closeTimer';
        divCloseTimer.style.width = '100%';
        divCloseTimer.style.height = '2px';
        divCloseTimer.style.marginTop = '-2px';
        divCloseTimer.style.backgroundColor = '#fe8e14';
        wrap.insertBefore(divCloseTimer, wrap.firstElementChild);
      }
      wrap.appendChild(wrap2);

      if(tools.isString(divContent)) {
        lib.setHtml(wrap2, divContent);
      }

      p.appendChild(wrap);
      document.body.appendChild(p);

      if(!tools.isString(divContent)) {
        if(divContent && divContent instanceof simpleJQ) {
          //   divContent.parent().remove(divContent);
          $(wrap2).append(divContent);
        } else {
          wrap2.appendChild(divContent);
        }
      }

      if(onClose) {
        let objClose:any = $('.ds-ui-dlg-close', $(p));
        if (objClose && objClose.length>0) {
          objClose = objClose[0];
          objClose.onClose = function(){
            tools.removeEventListener(objClose, 'click', objClose.onClose);
            objClose.onClose = null;
            onClose();
          };
          tools.addEventListener(objClose, 'click', objClose.onClose);
        }
      }

      if(darkBackground) {
        lib.setBackOpacity({
          opacity: 0.4,
          grayHex: 0
        });
      } else {
        lib.setBackOpacity({});
      }
    
      p['bTopmost'] = true;
      install._dlgInstall = p;
      lib.dialog.setup(install._dlgInstall, false);

    } else {
      bFirstShow = false;
    }

    let dlg = document.querySelector('.' + dlgWrapClass) as HTMLElement;
    if (dlg) {
      dlg.style.width = _dialogWidth + 'px';

      if (tools.isNumber(_dialogHeight) && _dialogHeight > 0) {
        dlg.style.height = _dialogHeight + 'px';
      } else {
        dlg.style.height = '100%';
      }

      if (!bFirstShow) {
        tools.each(dlg.childNodes, function (divTmp) {
          if ((divTmp.tagName == 'DIV') &&
            (divTmp.className != 'ds-ui-dlg-close') &&
            (divTmp.className != 'ds-ui-dlg-closeTimer')) {

              lib.setHtml(divTmp, divContent);

            return false;
          }
        });
      }
    }

    if (install._dlgInstall.open) {
      install._dlgInstall.close();
    }

    install._dlgInstall.showModal({
      position: position
    });
    install._dlgInstall.bReadyClosed = bReadyClosed;
    if(darkBackground) {
      lib.setBackOpacity({});
    }

    if (bClose) {

      let aryClose = document.querySelectorAll('.ds-ui-dlg-close');
      tools.each(aryClose, function (o, n) {
        tools.addEventListener(o, 'click', UI.CloseMessage);
      });

      if (aryClose.length > 0) {
        if (bAutoClose && _seconds > 0) {
          setTimeout(UI._zdgb_xkz_dhk, 100);
        }
      }

    }
  },
  _zdgb_xkz_dhk : function () {

    let dlgInstall = UI.install._dlgInstall;
    if (dlgInstall) {

      let sizzleResult = $('.ds-ui-dlg-closeTimer', dlgInstall);
      if (sizzleResult.length>0) {
        let divCloseTimer = sizzleResult[0];
        let v = parseInt(divCloseTimer.style.width);
        v -= 1;
        if (v <= 0) {
          UI.CloseMessage();
        } else {
          divCloseTimer.style.width = v + '%';
          setTimeout(UI._zdgb_xkz_dhk, 100);
        }
      }
    }
  }
}

export {
  UI
}