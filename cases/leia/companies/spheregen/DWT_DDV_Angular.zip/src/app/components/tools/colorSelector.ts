import { tools } from "./tools"
import { $ } from "src/app/components/tools/simpleJQ";

export class DDVColorSelector {
  maxColorNumber
  colorButtonClassName
  bShowAddColor
  placeHoderNumber
  colorValue
  eventForActiveColorButton
  el
  _evtButtonEl

  constructor(maxColorNumber, presetColors, colorButtonClassName) {
    this.maxColorNumber = maxColorNumber;
    let _presetColors = [];
    if (presetColors && presetColors.length > 0) {
      _presetColors = presetColors;
    }
    this.colorButtonClassName = colorButtonClassName;
    let remains = this.maxColorNumber - _presetColors.length;
    this.bShowAddColor = remains > 0;
    this.placeHoderNumber = remains - 1;
    if (this.placeHoderNumber < 0) {
      this.placeHoderNumber = 0;
    }
    this.genElements(_presetColors);
    this.colorValue = '';
    this.eventForActiveColorButton = null;
    this._evtButtonEl = null;
  }
  getEl() {
    return this.el;
  }
  setActiveColor(color) {
    this.clearActive();
    let _this = this;
    let colorEls = $(this.el).find('.ddv-button-palette-color');
    tools.each(colorEls, function (colorButtonEl) {
      if (colorButtonEl.value === color) {
        $(colorButtonEl).addClass('active');
        _this.colorValue = color;
        return false;
      }
    });
  }
  setEventForActiveColorButton(callbackEvent) {
    if (tools.isFunction(callbackEvent)) {
      this.eventForActiveColorButton = callbackEvent;
    }
  }
  setEventForColorChanged(callbackEvent) {
    if (tools.isFunction(callbackEvent)) {
      let inputColorEl = this.el.querySelector('.ddv-color-selector');
      $(inputColorEl).on('input', evt => {
        callbackEvent(evt);
      });
    }
  }
  genElements(_presetColors) {
    let el = document.createElement('div');
    el.className = "mt5 ddv-flex";
    let i = 0;
    for (; i < _presetColors.length; i++) {
      const color = _presetColors[i];
      let elColorButton = this.genColorButton(color);
      el.append(elColorButton);
    }
    if (this.bShowAddColor) {
      el.append(this.genAddButton());
      for (i = 0; i < this.placeHoderNumber; i++) {
        el.append(this.genPlaceholderButton());
      }
    }
    let elColorInput = document.createElement('input');
    elColorInput.className = "ddv-color-selector";
    elColorInput.type = 'color';
    let newDiv = document.createElement('div');
    newDiv.style.position = 'relative';
    newDiv.append(el);
    newDiv.append(elColorInput);
    this.el = newDiv;
    $(el).on('click', evt => {
      if (evt.target.className == 'ddv-add-color') {
        evt.stopPropagation();
        // click add color
        this._evtButtonEl = evt.target;
        let inputColorEl = this.el.querySelector('.ddv-color-selector');
        inputColorEl.focus();
        inputColorEl.click();
        return;
      }
      let clickEl = $(evt.target);
      if (!clickEl.hasClass('ddv-button-palette-color')) return;
      evt.stopPropagation();
      // set active
      this.clearActive();
      clickEl.addClass('active');
      this.colorValue = clickEl.attr('value');
      if (tools.isFunction(this.eventForActiveColorButton)) {
        this.eventForActiveColorButton(evt);
      }
    });
    $(el).on('dblclick', evt => {
      if (evt.target.className == 'ddv-add-color' || $(evt.target).hasClass('ddv-button-palette-color')) {
        evt.stopPropagation();
        // click add color
        let eventButtonEl = evt.target as HTMLInputElement;
        if (eventButtonEl.value === 'transparent') return;
        this._evtButtonEl = eventButtonEl;
        let inputColorEl = this.el.querySelector('.ddv-color-selector');
        inputColorEl.value = eventButtonEl.value;
        inputColorEl.focus();
        inputColorEl.click();
        return;
      }
    });
    // bind color input Events
    //$(elColorInput).on('input', evt=>{
    //});
    $(elColorInput).on('input', evt => {
      if (!this._evtButtonEl) return;
      let elButton = this._evtButtonEl,
        newColor = elColorInput.value;
      elButton.value = newColor;
      this.colorValue = newColor;
      $(elButton).find('div').css('background', newColor);
      if (this._evtButtonEl.className == 'ddv-add-color') {
        this.clearActive();
        elButton.className = `ddv-button-palette-color ${this.colorButtonClassName} active`;
        if (tools.isFunction(this.eventForActiveColorButton)) {
          this.eventForActiveColorButton(evt);
        }
        // set first holdplace as add
        let placeholders = $(this.el).find('.ddv-color-placeholder');
        if (placeholders && placeholders.length > 0) {
          placeholders[0].className = 'ddv-add-color';
        }
      }
    });
  }
  genColorButton(color) {
    const bTransparent = color == 'transparent';
    let btnTransparentClassName = bTransparent ? "ddv-color-transparent" : "";
    let elButton = document.createElement('button');
    elButton.className = `ddv-button-palette-color ${this.colorButtonClassName} ${btnTransparentClassName}`;
    elButton.value = color;
    let elButtonDiv = document.createElement('div');
    if (!bTransparent) {
      elButtonDiv.style.background = color;
    }
    elButton.append(elButtonDiv);
    return elButton;
  }
  genAddButton() {
    let elButton = document.createElement('button');
    elButton.className = "ddv-add-color";
    elButton.append(document.createElement('div'));
    return elButton;
  }
  genPlaceholderButton() {
    let elButton = document.createElement('button');
    elButton.className = "ddv-color-placeholder";
    elButton.append(document.createElement('div'));
    return elButton;
  }
  clearActive() {
    $(this.el).find('.ddv-button-palette-color.active').removeClass('active');
    this.colorValue = '';
  }
  addActive() {
    $(this.el).find('.ddv-button-palette-color.active').addClass('active');
    this.colorValue = '#333333';
  }
}