export class FontItem {
  
  fontStyle;
  fontSize;
  fontUnit;
  fontFamily;
  bold;
  italic;
  underLine;
  strikethrough;
  timeStampFontSize;

  constructor() {
    this.fontStyle = "normal";
    this.fontSize = 12;
    this.fontUnit = "px";
    this.fontFamily = "Arial";
    this.bold = false;
    this.italic = false;
    this.underLine = false;
    this.strikethrough = false;
    this.timeStampFontSize = 10;
  }
  
  setFontSize(_size) {
    this.fontSize = _size;
    if(_size<=28) {
      this.timeStampFontSize = 11;
    } else {
      this.timeStampFontSize = Math.floor(parseInt(_size) * 0.4);
    }
  }

  getFontString() {
    let strBold = this.bold ? "bold" : "",
      strFontFamily = this.fontFamily;
    if (strFontFamily.includes(" ")) {
      return `${this.fontStyle} ${strBold} ${this.fontSize}${this.fontUnit} '${strFontFamily}'`;
    }
    return `${this.fontStyle} ${strBold} ${this.fontSize}${this.fontUnit} ${strFontFamily}`;
  }
}
export class CustomStampItem {

  text;
  fontItem;
  textColor;
  borderColor;
  backgroundColor;
  userName;
  hasUserName = false;
  hasDate = false;
  hasTime = false;
  dateFormat;

  constructor() {
    this.text = '';
    this.fontItem = new FontItem();
    this.textColor = '#000000';
    this.borderColor = '#000000';
    this.backgroundColor = '#FFFFFF';
    this.userName = '';
    this.hasUserName = false;
    this.hasDate = false;
    this.hasTime = false;
    this.dateFormat = 'MM/dd/yyyy';
  }
}