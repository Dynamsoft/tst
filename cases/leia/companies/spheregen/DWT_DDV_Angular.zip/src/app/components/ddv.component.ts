import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { Observable } from 'rxjs';
import { FormsModule } from '@angular/forms';

import { CallbackPipe } from '../callback.pipe';
import { SafeurlPipe } from '../safeurl.pipe';

import { DDVAnnotationMenuStamp } from "../../annotation/DDVAnnotationMenuStamp";
import { DDVAnnotationMenuSign } from "../../annotation/DDVAnnotationMenuSign";

import { tools } from "./tools/tools";
import { $ } from "./tools/simpleJQ";
import { UI } from "./tools/uiDialog";

import { DDV_ImagePath, DDVExperimentsTool, Dynamsoft_Ref, environment, resourceRoot, timestamp } from "../../globalObjects";
import { initMenuPresets } from "../../annotation/preset/presets";
import { annotationMenuMap, getCurrentViewerGroups, initAllMenu, inkSignatureImageMap, lastSelected, stampImageMap } from "../../menu/lastMenu";
import { insertMenu_OpenImageFile, insertMenu_Select, insertMenu_sign } from "../../menu/insertMenu";
import { createNewInkSignatureDialog, inkSignatureBoard } from "../../menu/createNewInkSignature";
import { createNewStampDialog, fontStyleChanged, redrawStamp, stampSignatureBoard } from "../../menu/createNewStamp";
import { hidePalette, isShowPalette, showPalette } from "./tools/palette";
import { DDV } from "dynamsoft-document-viewer";
import { getEl } from './tools/common';

let jQuery, ddvScanDialog;

@Component({
  imports: [
    FormsModule,
    CallbackPipe,
    SafeurlPipe
  ],
  selector: 'app-ddv',
  templateUrl: './ddv.component.html',
  standalone: true
})
export class DDVAppComponent implements OnInit, OnDestroy {
  @Input() events: Observable<void>;

  constructor() {
  }

  ngOnInit() {

    loadResources(() => {

      jQuery = window['jQuery']; // for jQuery ui dialog
      window['dynamsoftCore'] = window['config'] = window['_interface'] = {}; // for DDV_Resources/dynamsoft-license@3.2.21/dist/license.js

      $('.ds-button-scan').on("click", scanButtonClickHandler);

      const _ddvScanDialog = jQuery('.ddv-scan-dialog');
      if(_ddvScanDialog && _ddvScanDialog.dialog) {
        ddvScanDialog = _ddvScanDialog;
        ddvScanDialog.dialog({
          autoOpen: false,
          modal: true,
          width: 550
        });
      }

      createNewStampDialog();
      createNewInkSignatureDialog();
      CreateDDVObjectAsync({
          ContainerId: 'ddvControlContainer',
          DDV_engineResourcePath: environment.Dynamsoft.ddvEngineResourcePath,
          DDV_license: environment.Dynamsoft.ddvProductKey
      }).then(function () {
          DDVObject_OnReady();
      }).catch(function (exp) {
          console.error(exp);
      });
      initAllMenu();
      initSaveDialog();

    });

  }

  ngOnDestroy() {
  }

}

async function loadResources(callback) {
  const scripts = [
    "js/jquery.min.js",
    "js/jquery-ui.min.js",
    "DDV_Resources/dynamsoft-core@3.2.30/dist/core.js",
    "DDV_Resources/dynamsoft-license@3.2.21/dist/license.js",
    "js/ddv-demo-tools-with-dwt.js",
    "js/html5tooltips.js"
  ];
  await loadScripts(scripts);
  if(callback) callback();

}

async function loadScripts(urls) {
  let i = 0;
  for(; i<urls.length; i++) {
    await loadOneScript(urls[i]);
  }
}

async function loadOneScript(url) {
  return new Promise(function(resolve, reject){
    Dynamsoft_Ref.Lib.getScript(url, true, function(){
      resolve(1);
    });
  });
}

function signResetHandler() {

  inkSignatureBoard.clearSignature();

}
function bindSignPopuiEvents() {
  
  inkSignatureBoard.updateSignatureStyle({     
    borderColor: '#000'
  });

  const inkSignature_canvas =  inkSignatureBoard.getCanvas();
  if (inkSignature_canvas) {
    signResetHandler();
  }

}
let bFirstTime_sign = true;
function bindDDVSignEvents() {
  signResetHandler();
  if (!bFirstTime_sign) {
    return;
  }
  $('.draw-group-button .Button').on('click', function (evt) {
    let el = $(evt.target);
    evt.stopPropagation();
    $('.draw-group-button.active').removeClass('active');
    el.parent().addClass('active');

    // colorRgbToHex
    inkSignatureBoard.updateSignatureStyle({
	    borderColor: el.css('color')
	  });
  });
  
  $('.ddv-sign .ddv-palette-stroke-range').on('change', function (evt) {
    evt.stopPropagation();
    inkSignatureBoard.updateSignatureStyle({     
	    borderWidth: evt.target.value
	  });
  });
  bFirstTime_sign = false;
}

function viewerResize() {
  let divMain = document.querySelector('ds-dv-main') as HTMLElement;
  if (divMain) {
    divMain.style.height = document.body.clientHeight + 'px';
  }
  let ddvContainer = getEl('ddvControlContainer');
  if (ddvContainer) {
    let menuHeight = 90;
    ddvContainer.style.height = document.body.clientHeight - menuHeight + 'px';
  }
}
window.addEventListener('resize', function (evt) {
  viewerResize();
});


function copyColorFromPreset(curAnnotationMenu, presetObj) {
  let color, fill, strokeColor;
  color = presetObj.annotation.color;
  fill = presetObj.annotation.fill;
  strokeColor = presetObj.annotation.strokeColor;
  curAnnotationMenu.setMenuColor(color);
  curAnnotationMenu.setMenuFill(fill);
  curAnnotationMenu.setMenuStroke(strokeColor);
}
function setActiveButtonColor(curAnnotationMenu) {
  tools.each(curAnnotationMenu.presetEls, function (presetObj) {
    if (presetObj.isActive()) {
      copyColorFromPreset(curAnnotationMenu, presetObj);
      return false;
    }
  });
}
function resetMenuColor() {
  if (lastSelected.viewer != '') {
    const curActiveMenu = lastSelected[lastSelected.viewer];
    if (!curActiveMenu) return;
    const groups = getCurrentViewerGroups();
    tools.each(groups, function (otherAnnotation) {
      if (otherAnnotation != curActiveMenu) {
        otherAnnotation.setInActive();
      } else {
        setActiveButtonColor(curActiveMenu);
      }
    });
  }
}
function setNoPresetsStyle() {
  $('.ds-div-presets').html('No Presets');
  $('.ds-div-presets').css('background', 'transparent');
}
function updateContinuousDrawing() {
  setIgnoreAnnotationDefaultStyleChanged();
  if (lastSelected.viewer == 'insert' || lastSelected.viewer == '') {
    DDVExperimentsTool.editFullViewer.updateAnnotationConfig({
      enableContinuousDrawing: false
    });
    return;
  }
  DDVExperimentsTool.editFullViewer.updateAnnotationConfig({
    enableContinuousDrawing: true
  });
}
function setIgnoreAnnotationDefaultStyleChanged() {
  DDVExperimentsTool.ignoreAnnotationDefaultStyleChanged = true;
}
function EnableMenu() {
  $('.menu-annotation').removeClass('ddv-button-disabled');
  $('.menu-insert').removeClass('ddv-button-disabled');
  $('.menu-shapes').removeClass('ddv-button-disabled');
}
function DisableMenu() {
  $('.menu-annotation').addClass('ddv-button-disabled');
  $('.menu-insert').addClass('ddv-button-disabled');
  $('.menu-shapes').addClass('ddv-button-disabled');
}

async function CreateDDVObjectAsync(config) {
    DDV.Core.engineResourcePath = config.DDV_engineResourcePath;
    DDV.Core.license = config.DDV_license;
    Dynamsoft_Ref.Lib.showMask();
    try {
      await DDV.Core.init();
      DDV.Elements.setTooltip({
        ThumbnailSwitch: "Switch Thumbnail",
        Load: "Load Image",
        DeleteCurrent: "Delete Current Image",
        DeleteAll:"Delete All Images",
        Download: 'Save Images as PDF',
        FitMode: 'Fit Mode',
        Undo: 'Undo',
        Redo: 'Redo',
        RotateLeft: 'Rotate Left',
        Crop: 'Crop',
        Pan: 'View Mode',
        TextSearchPanelSwitch: "Text Search Panel Switch",
        TextSelectionMode: "Text Selection Mode",

        ZoomIn: "Zoom In",
        ZoomOut: "Zoom Out",
        FirstPage: "First Page",
        LastPage: "Last Page",
        NextPage: "Next Page",
        PrevPage: "Previous Page",
        SelectAnnotation:"Select Annotation(s)",
        EraseAnnotation:"Erase"
      });
      DDV.Elements.setDisplayTextConfig({
        ThumbnailSwitch: "Thumbnail",
        Load: "Load",
        DeleteCurrent: "Delete",
        DeleteAll:"DeleteAll",
        /*ZoomIn: "ZoomIn",
        ZoomOut: "ZoomOut",
        FirstPage: "First",
        LastPage: "Last",
        NextPage: "Next",
        PrevPage: "Previous ",*/
        FitMode:"FitMode",
        Undo: 'Undo',
        Redo: 'Redo',
        RotateLeft: 'RotateLeft',
        Crop: 'Crop',
        Pan: 'Hand',
        TextSelectionMode:"SelectText",
        TextSearchPanelSwitch:"Search",
        SelectAnnotation: "Select",
        EraseAnnotation: "Erase"
      });
      DDVExperimentsTool.ddvObject = DDV.documentManager.createDocument({
        name: "ddvtestDoc"
      });
      DDV.documentManager.on("pagesAdded", refObj => {
        let total = DDV.documentManager.getDocument(refObj.docUid).pages.length;
        if (total > 0) {
          // loaded pages
          EnableMenu();
          let inputGoto = document.querySelector('.ddv-pagination-goto') as HTMLInputElement;
          inputGoto.readOnly = true;
          inputGoto.disabled = true;
        }
      });
      DDV.documentManager.on("pagesDeleted", refObj => {
        let total = DDV.documentManager.getDocument(refObj.docUid).pages.length;
        if (total == 0) {
          DisableMenu();
        }
      });
      DDV.on("error", exp => {
        console.error(exp.message);
        alert(exp.message);
      });
      let cid = config.ContainerId;
      let elContainer = getEl(cid) as HTMLElement;
      elContainer.innerHTML = "";
      DDVExperimentsTool.editViewer = new DDV.EditViewer({
        container: cid,
        annotationConfig: {
          showOnTopWhenSelected: true,
          enableContinuousDrawing: true,
          defaultStyleConfig: {
            stamp: {
              stamp: DDV.EnumStampIcon.DRAFT
            },
            //{
            //  imageData: null,
            //  stampIcon: [DDV.EnumStampIcon.REJECTED, DDV.EnumStampIcon.ACCEPTED, DDV.EnumStampIcon.INITIAL_HERE, DDV.EnumStampIcon.SIGN_HERE, 
            //    DDV.EnumStampIcon.WITNESS, DDV.EnumStampIcon.APPROVED, DDV.EnumStampIcon.NOT_APPROVED, DDV.EnumStampIcon.DRAFT, 
            //    DDV.EnumStampIcon.FINAL, DDV.EnumStampIcon.COMPLETED, DDV.EnumStampIcon.CONFIDENTIAL, DDV.EnumStampIcon.VOID]
            //},
            //baseAnnotationStyle: {
            //  textContent: {
            //    fontSize: 32
            //  },
            //  borderWidth: 3.0
            //}
          }
        },
        uiConfig: {
          type: DDV.Elements.Layout,
          flexDirection: "column",
          className: "ddv-edit-viewer-desktop",
          children: [{
            type: DDV.Elements.Layout,
            className: "ddv-edit-viewer-header-desktop",
            children: [{
              type: DDV.Elements.Layout,
              children: [
                DDV.Elements.ThumbnailSwitch,
                {
                  type: DDV.Elements.Button,
                  className: "ddv-scan-image",
                  label: "Scan",
                  tooltip: "Scan Image",
                  events: {
                    "click": clickToolbarScanButton,
                  }
                },
                DDV.Elements.Load,
                DDV.Elements.DeleteCurrent,DDV.Elements.DeleteAll,
                DDV.Elements.Pagination, DDV.Elements.Zoom, 
                DDV.Elements.FitMode,

                DDV.Elements.Undo, DDV.Elements.Redo, // DDV.Elements.SelectAnnotation, DDV.Elements.EraseAnnotation,
                DDV.Elements.RotateLeft,DDV.Elements.Crop,
                DDV.Elements.Pan,
                DDV.Elements.TextSelectionMode,

                {
                  type: DDV.Elements.Button,
                  className: "ddv-button ddv-button-download",
                  label: "Save",
                  tooltip: "Save as PDF",
                  events: {
                    "click": downloadDialog,
                  }
                },
                DDV.Elements.TextSearchPanelSwitch
                //,
                //{
                //  type: DDV.Elements.Layout,
                //  className: "divider",
                //  label: "",
                //  tooltip: "",
                //}
              ]
            }]
          }, 
          {
            type: DDV.Elements.Layout,
            flexDirection:"row",
            children:[
                DDV.Elements.MainView,
                {
                    type: DDV.Elements.TextSearchPanel,
                    className: "ddv-edit-viewer-search-pc"
                }
            ]
          }
          ]
        },
        thumbnailConfig: {
          checkboxStyle: {
            visibility: "hidden"
          }
        },
        viewerConfig: {
          scrollToLatest: true,
          enableLoadSourceByDrag: false, 
          //displayMode: 'continuous',  // 3.0.0 is removed
          //enableDragPage: true,
          //pageNumberStyle: {
          //  visibility: "hidden"
          //},
          //checkboxStyle: {
          //  visibility: "hidden"
          //}
        }
      });
      DDVExperimentsTool.editViewer.openDocument(DDVExperimentsTool.ddvObject.uid);
      DDVExperimentsTool.editViewer.on("annotationDefaultStyleChanged", refObj => {
        if (DDVExperimentsTool.ignoreAnnotationDefaultStyleChanged) {
          DDVExperimentsTool.ignoreAnnotationDefaultStyleChanged = false;
        } else {
          updateCurrentPreset(refObj[DDVExperimentsTool.editViewer.annotationMode]);
        }
      });
      DDVExperimentsTool.editViewer.on("selectedAnnotationsChanged", refObj => {
        if (refObj.newAnnotationUids.length == 1) {
          unselectStampMenuWhenImageStampEnd();
        }
      });
      DDVExperimentsTool.editViewer.thumbnail.show();
      DDVExperimentsTool.thumbnail = DDVExperimentsTool.editViewer.thumbnail;
      DDVExperimentsTool.editFullViewer = DDV.Experiments.get("InnerViewer",DDVExperimentsTool.editViewer.uid);
      DDVExperimentsTool.thumbnailFullViewer = DDV.Experiments.get("InnerViewer",DDVExperimentsTool.editViewer.thumbnail.uid);

    } finally {
      Dynamsoft_Ref.Lib.hideMask();
    }
    return DDVExperimentsTool.ddvObject;
}
function unselectStampMenuWhenImageStampEnd() {
  let currentMode = DDVExperimentsTool.editViewer.annotationMode;
  if (currentMode == 'stamp') {
    let curViewerName = lastSelected.viewer;
    if (curViewerName === 'insert') {
      if (lastSelected[curViewerName] === insertMenu_OpenImageFile) {
        lastSelected[curViewerName].setInActive();
        (lastSelected[curViewerName] as any) = null;
        setNoPresetsStyle();
        updateContinuousDrawing();
      }
    }
  }
}
function updateCurrentPreset(uiConfig) {
  let curViewerName = lastSelected.viewer,
    curActiveMenu;
  if (curViewerName != '') {
    curActiveMenu = lastSelected[curViewerName];
  }
  if (!uiConfig || !curActiveMenu) {
    return;
  }
  let color, fill, strokeColor;
  let toolMode = curActiveMenu.getElDataToolMode();

  if(toolMode == 'annotation') {
      
    let mode = curActiveMenu.getElData();
    if (mode == 'rectangle' || mode == 'ellipse' || mode == 'polygon') {
      color = uiConfig.borderColor;
      fill = uiConfig.background;
    } else if (mode == 'textTypewriter' || mode == 'textBox') {
      color = uiConfig.textContent.color;
      if (mode == 'textBox') {
        strokeColor = uiConfig.borderColor;
        fill = uiConfig.background;
      }
    } else if (mode == 'highlight') {
      color = uiConfig.background;
    } else {
      color = uiConfig.borderColor;
    }

  } else {
    return;
  }

  let bNeedUpdateConfig = false;
  if (fill == 'none' || fill == 'transparent') {
    // update back as empty string
    fill = '';
    bNeedUpdateConfig = true;
  }
  curActiveMenu.setMenuColor(color);
  curActiveMenu.setMenuFill(fill);
  curActiveMenu.setMenuStroke(strokeColor);

  tools.each(curActiveMenu.presetEls, function (presetObj) {
    if (presetObj.isActive()) {
      presetObj.annotation.color = color;
      presetObj.annotation.fill = fill;
      presetObj.annotation.strokeColor = strokeColor;

      presetObj.annotation.setMenuColor(color);
      presetObj.annotation.setMenuFill(fill);
      presetObj.annotation.setMenuStroke(strokeColor);
      if (bNeedUpdateConfig) {
        let updateConfig = presetObj.annotation.getUpdateConfig();
        setIgnoreAnnotationDefaultStyleChanged();
        DDVExperimentsTool.editFullViewer.updateAnnotationConfig(updateConfig);
      }
      return false;
    }
  });
}
function clearSelectedMainMenu() {
  $('.menu-group').each(function (n, el) {
    $(el).removeClass('active');
  });
}
function bindMainMenuClickEvent(callbackFun) {
  $('.menu-group').on('click', function (evt) {
    clearSelectedMainMenu();
    $(evt.target).addClass('active');
    callbackFun(evt);
  });
}

let bFirstTime_stamp = true,
  bInputUnicode = false;
function bindStampPopuiEvents() {
  const stamp_canvas =  stampSignatureBoard.getCanvas();
  if (stamp_canvas) {
    redrawStamp();
  }

  if (!bFirstTime_stamp) return;
  $('.ddv-stamp-text').on("compositionstart", function (evt) {
    evt.stopPropagation();
    bInputUnicode = true;
  });
  $('.ddv-stamp-text').on("compositionend", function (evt) {
    evt.stopPropagation();
    bInputUnicode = false;
    redrawStamp(evt.target);
  });
  $('.ddv-stamp-text').on('input', evt => {
    evt.stopPropagation();
    if (bInputUnicode) return;
    redrawStamp(evt.target);
  });
  $('.ddv-stamp-text').on('blur', evt => {
    evt.stopPropagation();
    redrawStamp(evt.target);
  });
  $('.ddv-stamp-text-size').on('change', evt => {
    evt.stopPropagation();
    redrawStamp(evt.target);
  });
  $('.ddv-stamp-font-style-container .ddv-bold').on('click', evt => {
    evt.stopPropagation();
    fontStyleChanged(evt);
  });
  $('.ddv-stamp-font-style-container .ddv-italic').on('click', evt => {
    evt.stopPropagation();
    fontStyleChanged(evt);
  });
  $('.ddv-stamp-font-style-container .ddv-underline').on('click', evt => {
    evt.stopPropagation();
    fontStyleChanged(evt);
  });
  $('.ddv-stamp-font-style-container .ddv-line-through').on('click', evt => {
    evt.stopPropagation();
    fontStyleChanged(evt);
  });
  $('.ddv-stamp-font-style-container .ddv-custom-stamp-select-font').on('change', evt => {
    evt.stopPropagation();
    redrawStamp();
  });

  $('.ddv-stamp-user').on('input', (evt) => { evt.stopPropagation(); if(bInputUnicode) return; redrawStamp(evt.target); } );
  $('.ddv-stamp-user').on('blur', (evt) => { evt.stopPropagation(); redrawStamp(evt.target); } );

  $('#ds-ddv-stamp-chk-username').on('change', (evt) => { evt.stopPropagation(); redrawStamp(evt.target); } );
  $('#ds-ddv-stamp-chk-date').on('change', (evt) => { evt.stopPropagation(); redrawStamp(evt.target); } );
  $('#ds-ddv-stamp-chk-time').on('change', (evt) => { evt.stopPropagation(); redrawStamp(evt.target); } );

  bFirstTime_stamp = false;
}

function closePopUI() {
  UI.CloseMessage();
  $('.ddv-popup-dialog').hide();
  $('.ddv-sign').hide();
  $('.ddv-new-stamp').hide();
  $('.ddv-save-dialog').hide();
  $('.ddv-pdf-password-dialog').hide();
}

const BLANK_SIGN_IMAGE_URL = `${DDV_ImagePath}/blank.png`;

function onClickStamp_new(evt) {
  onClickStamp(evt, 'new');
}
function onClickStamp_custom(evt) {
  onClickStamp(evt, 'custom');
}
function onClickStamp_system(evt) {
  onClickStamp(evt, 'system');
}

async function onClickStamp(evt, from) {
    let el = evt.target;
    evt.stopPropagation();
    $('.ddv-popup-dialog').hide();
    let dropdownImageEl = document.querySelector('.ds-stamp-dropdown img') as HTMLImageElement,
      signatureStyle, 
      _blob;
    let data = el.getAttribute('data') || '';
    // check map
    if (data != '') {
      signatureStyle = stampImageMap[data];
      dropdownImageEl.setAttribute('data', data);
    } else {
      // maybe system
    }

    DDVExperimentsTool.editViewer.toolMode = 'annotation';
    if (signatureStyle) {
      stampSignatureBoard.updateSignatureStyle(signatureStyle);
      redrawStamp(null, false);
      const stamp_canvas =  stampSignatureBoard.getCanvas();
      _blob = await new Promise(function (resolve, reject) {
        stamp_canvas.toBlob(function (_newBlob) {
          resolve(_newBlob);
        });
      });
      let newUrl = URL.createObjectURL(_blob);
      el.src = newUrl;
      dropdownImageEl.src = el.src;
      default_stamp_obj = {
        type: 'custom',
        signatureStyle: signatureStyle
      };

      DDVExperimentsTool.editViewer.setAnnotationDrawingStyle({
        stamp: {
          stamp: stampSignatureBoard.getStampConfig()
        }
      });
    } else {
      dropdownImageEl.src = el.src;
      if (data !== '') {
        default_stamp_obj = {
          data: data,
          type: 'system'
        };
      } else {
        _blob = await (await fetch(el.src)).blob();
        default_stamp_obj = {
          data: _blob,
          type: 'custom'
        };
      }
      updateStampAnnotationConfig();
    }
    DDVExperimentsTool.editViewer.annotationMode = "stamp";
}
function showPopUI_signature() {
  let divDDVSign = $('.ddv-sign');
  closePopUI();
  UI.ShowMessage(divDDVSign, {
    headerStyle: 0
  });
  divDDVSign.show();
  preSignAnnotationMenu = lastSelected.insert;
  if (!preSignAnnotationMenu) {
    preSignAnnotationMenu = insertMenu_Select;
  }
  DDVExperimentsTool.editViewer.selectAnnotations([]);
  DDVExperimentsTool.editViewer.toolMode = "annotation";
  DDVExperimentsTool.editViewer.annotationMode = "select";
  bindDDVSignEvents();
}
function showPopUI_stamp() {
  let divDDVNewStamp = $('.ddv-new-stamp');
  closePopUI();
  UI.ShowMessage(divDDVNewStamp, {
    headerStyle: 0
  });
  divDDVNewStamp.show();
  preSignAnnotationMenu = lastSelected.insert;
  if (!preSignAnnotationMenu) {
    preSignAnnotationMenu = insertMenu_Select;
  }
  DDVExperimentsTool.editViewer.selectAnnotations([]);
  DDVExperimentsTool.editViewer.toolMode = "annotation";
  DDVExperimentsTool.editViewer.annotationMode = "select";
}
function setPresetStyle() {
  $('.ds-div-presets').css('background', '');
}
function resetPreset(curAnnotationMenu) {
  let mode = '';
  if (curAnnotationMenu) {
    mode = curAnnotationMenu.getElData();
  }
  if (mode == 'image') {
    return;
  }
  if (mode == '') {
    setNoPresetsStyle();
    updateContinuousDrawing();
    return;
  } else {
    setPresetStyle();
  }
  let curEl = curAnnotationMenu.getEl();
  $(curEl).parent().parent().find('.active').removeClass('active');
  curAnnotationMenu.setActive();
  updateContinuousDrawing();
  resetMenuColor();
  let presetElements = curAnnotationMenu.presetEls;
  if (presetElements && presetElements.length > 0) {
    setPresetStyle();
    if (curAnnotationMenu instanceof DDVAnnotationMenuStamp) {
      let presetObj = curAnnotationMenu.presetEls[0];
      $('.ds-div-presets').html('');
      $('.ds-div-presets').append(presetObj.wrapperEl);
      presetObj.bindEvents(() => {
        showPopUI_stamp();
      });
      $(presetObj.wrapperEl).find('.ddv-system-stamp img').on('click', evt => onClickStamp_system(evt));
      $(presetObj.wrapperEl).find('.ddv-custom-stamp img').on('click', evt => onClickStamp_custom(evt));
      curEl = null;
    } else if (curAnnotationMenu instanceof DDVAnnotationMenuSign) {
      let presetObj = curAnnotationMenu.presetEls[0];
      $('.ds-div-presets').html('');
      $('.ds-div-presets').append(presetObj.wrapperEl);
      presetObj.bindEvents(() => {
        showPopUI_signature();
      });
      $(presetObj.wrapperEl).find('.ds-stamp-sign-dropdown img').on('click', evt => onClickSign(evt));
      if (presetObj.isSignsEmpty) {
        showPopUI_signature();
      } else {
        // select first as sign stamp
        $(presetObj.wrapperEl).find('.ds-stamp-sign-dropdown img').click();
      }
      curEl = null;
    }
    if (curEl) {
      // change presets, copy <svg> then set color
      $('.ds-div-presets').html('');
      tools.each(presetElements, function (presetObj) {
        let presetElement = presetObj.wrapperEl;
        $('.ds-div-presets').append(presetElement);
        if (!presetObj.isBoundEvents()) {
          presetObj.setBoundEvents();
          $(presetElement).find('.ds-icon-dropdown').on('click', function (evt) {
            if (isShowPalette()) {
              hidePalette();
            } else {
              showPalette();
            }
          });
          let presetButtonEl = presetObj.annotation.elButton;
          $(presetButtonEl).on('click', function (evt) {
            hidePalette();
            tools.each(curAnnotationMenu.presetEls, function (presetObj) {
              if (presetObj.isActive()) {
                presetObj.setInActive();
                return false;
              }
            });
            presetObj.setActive();
            copyColorFromPreset(curAnnotationMenu, presetObj);
            let updateConfig = presetObj.annotation.getUpdateConfig();
            setIgnoreAnnotationDefaultStyleChanged();
            DDVExperimentsTool.editFullViewer.updateAnnotationConfig(updateConfig);
            $('.ddv-palette-box').css('display', '');
            
            let toolMode = curAnnotationMenu.getElDataToolMode();
            DDVExperimentsTool.editViewer.toolMode = toolMode;
            if(toolMode == 'annotation') {
              DDVExperimentsTool.editViewer.annotationMode = mode;
            }

            $('.ddv-palette-box').hide();
          });
        }
        if ($(presetElement).hasClass('active')) {
          $(presetElement).find('.Button').click();
        }
      });
      // get button color from selected preset
      setActiveButtonColor(curAnnotationMenu);
    }
  } else {
    setNoPresetsStyle();
  }
  DDVExperimentsTool.editViewer.toolMode = curAnnotationMenu.getElDataToolMode();
  if (curAnnotationMenu instanceof DDVAnnotationMenuStamp && default_stamp_obj) {
    updateStampAnnotationConfig();
  }
  DDVExperimentsTool.editViewer.annotationMode = mode;
  $('.ddv-palette-box').hide();
}
function updateStampAnnotationConfig() {
  let stampInfo;
  if(default_stamp_obj) {
    if(default_stamp_obj.config) {
      stampInfo = default_stamp_obj.config;
    } else if(default_stamp_obj.signatureStyle) {
      stampSignatureBoard.updateSignatureStyle(default_stamp_obj.signatureStyle);
      stampInfo = stampSignatureBoard.getStampConfig();
    } else if(default_stamp_obj.data) {
      stampInfo = default_stamp_obj.data;
      if(default_stamp_obj.type === 'system') {
        // system, convert name
        stampInfo = convertSystemStampName(stampInfo);
      }
    }
  }

  if(stampInfo) {
    DDVExperimentsTool.editViewer.setAnnotationDrawingStyle({
        stamp: {
          stamp: stampInfo
        }
    });
  }
}

function convertSystemStampName(inputName) {

  let ret;

  switch(inputName) {
    case "SHAccepted": ret="accepted";break;
    case "SBApproved": ret="approved";break;
    case "SBCompleted": ret="completed";break;
    case "SBConfidential": ret="confidential";break;
    case "SBDraft": ret="draft";break;
    case "SBFinal": ret="final";break;
    case "SHInitialHere": ret="initialHere";break;
    case "SBNotApproved": ret="notApproved";break;
    case "SBRejected": ret="rejected";break;
    case "SHSignHere": ret="signHere";break;
    case "SBVoid": ret="void";break;
    case "SHWitness": ret="witness";break;
  }

  return ret;
}

function onMenuViewerChanged() {
  resetMenuColor();
  let curViewerName = lastSelected.viewer,
    lastAnnotationMenu;
  if (curViewerName != '') {
    lastAnnotationMenu = lastSelected[curViewerName];
  }
  resetPreset(lastAnnotationMenu);
}
function DDVObject_OnReady() {

/*
  // Select the parent div where the button will be added
  const parentDiv = document.querySelector('.ds-menu-annotation-buttons');

  // Append the button inside the div
  const button_select = document.querySelector('button.ddv-annot-select');
  parentDiv.appendChild(button_select);

  const button_erase = document.querySelector('button.ddv-annot-eraser');
  parentDiv.appendChild(button_erase);

  const button_undo = document.querySelector('button.ddv-undo-page');
  parentDiv.appendChild(button_undo);

  const button_redo = document.querySelector('button.ddv-redo-page');
  parentDiv.appendChild(button_redo);

  const button_search = document.querySelector('button.ddv-search-switch');
  parentDiv.appendChild(button_search);
*/
  let menu2 = document.querySelector('.HeaderToolsContainer');
  if (menu2) {
    let ddvContainerViewerHeader = document.querySelector('.ddv-edit-viewer-desktop') as HTMLElement;
    ddvContainerViewerHeader.insertBefore(menu2, ddvContainerViewerHeader.firstChild);
  }
  $('.tool-group-button').on('click', function (evt) {
    hidePalette();
    let curAnnotationMenu = annotationMenuMap[evt.target.id];
    if (curAnnotationMenu) {
      if (curAnnotationMenu == lastSelected[lastSelected.viewer]) {
        // select actived preset, click it
        tools.each(curAnnotationMenu.presetEls, function (presetObj) {
          if (presetObj.isActive()) {
            $(presetObj.annotation.elButton).click();
            return false;
          }
        });
        if (curAnnotationMenu instanceof DDVAnnotationMenuStamp) {
          DDVExperimentsTool.editViewer.toolMode = 'annotation';
          if (default_stamp_obj) {
            updateStampAnnotationConfig();
          }
          DDVExperimentsTool.editViewer.annotationMode = "stamp";
        } else if (curAnnotationMenu instanceof DDVAnnotationMenuSign) {
          let presetObj = curAnnotationMenu.presetEls[0];
          if (presetObj && presetObj.wrapperEl) {
            $(presetObj.wrapperEl).find('.ds-stamp-sign-dropdown img').click();
          }
        } else {
          let toolMode = curAnnotationMenu.getElDataToolMode();
          if(DDVExperimentsTool.editViewer.toolMode != toolMode) {
            DDVExperimentsTool.editViewer.toolMode = toolMode;
          }
        }
      } else {
      
        let toolMode = curAnnotationMenu.getElDataToolMode();
        if(DDVExperimentsTool.editViewer.toolMode != toolMode) {
          DDVExperimentsTool.editViewer.toolMode = toolMode;
        }
        
        lastSelected[lastSelected.viewer] = curAnnotationMenu;
        resetPreset(curAnnotationMenu);
      }
    }
  });
  bindMainMenuClickEvent(evt => {
    let mode = $(evt.target).attr('data-element');
    if (mode == 'view') {
      $('.HeaderToolsContainer').hide();
      //$('.ddv-edit-viewer-header-desktop .ddv-layout').show();
      $('.ddv-edit-viewer-header-desktop').show();
      lastSelected.viewer = '';
      DDVExperimentsTool.editViewer.toolMode = "pan";
      DDVExperimentsTool.editViewer.annotationMode = "select";
      onMenuViewerChanged();
      updateContinuousDrawing();
    } else {
      $('.HeaderToolsContainer').show();
      //$('.ddv-edit-viewer-header-desktop .ddv-layout').hide();
      $('.ddv-edit-viewer-header-desktop').hide();
      $('.buttons-group-annotation').hide();
      $('.buttons-group-insert').hide();
      $('.buttons-group-shapes').hide();
      $('.ddv-fit-type-box').hide();
      $('.ddv-fit-window').removeClass('ddv-button-activated');
      $('.ddv-zoom-percentage-box').hide();
      if (mode == 'annotation') {
        $('.buttons-group-annotation').show();
      } else if (mode == 'insert') {
        $('.buttons-group-insert').show();
      } else if (mode == 'shapes') {
        $('.buttons-group-shapes').show();
      }
      lastSelected.viewer = mode;
      onMenuViewerChanged();
    }
    viewerResize();
  });
  if (insertMenu_OpenImageFile) {
    insertMenu_OpenImageFile.bindClickEvent((files, blob) => {
      if (!blob || !files || files.length == 0 || !["image/png", "image/jpeg", "image/bmp"].includes(files[0].type)) {
        unselectStampMenuWhenImageStampEnd();
        return;
      }
      DDVExperimentsTool.editViewer.toolMode = 'annotation';
      DDVExperimentsTool.editViewer.setAnnotationDrawingStyle({
        stamp: {
          stamp: blob
        }
      });
      DDVExperimentsTool.editViewer.annotationMode = "stamp";
    }, () => {
      hideTooltips();
      let curViewerName = lastSelected.viewer;
      if (curViewerName != '') {
        if (lastSelected[curViewerName]) {
          lastSelected[curViewerName].setInActive();
        }
        lastSelected[curViewerName] = insertMenu_OpenImageFile;
      }
    });
  }
  initMenuPresets();
  initLoad();
  wrapperLoadImage(DDVExperimentsTool.ddvObject);
  viewerResize();
  bindPopuiEvents();
  refreshTooltips();
}
function refreshTooltips() {
  if (window['html5tooltips']) window['html5tooltips'].refresh();
}
function hideTooltips() {
  let el = document.querySelector('.html5tooltip-bottom') as HTMLElement;
  if (el) el.style.visibility = 'hidden';
}
function bindPopuiEvents() {
  bindSignPopuiEvents();
  bindStampPopuiEvents();
  // sign buttons events in pop ui
  $('.ddv-button-sign-create').on('click', evt => {
    createNewSignHandler();
  });
  $('.ddv-button-sign-clear').on('click', evt => {
    signResetHandler();
  });
  $('.ddv-button-sign-cancel').on('click', evt => {
    cancelSignHandler();
  });
  // stamp button event in pop ui
  $('.ddv-button-stamp-create').on('click', evt => {
    createNewStampHandler(evt);
  });
  $('.ddv-button-stamp-cancel').on('click', evt => {
    cancelNewStampHandler();
  });
}
let preSignAnnotationMenu;
let default_stamp_obj: any = {
    data: "SBDraft",
    type: 'system'
  },
  default_sign_imgBlob = null;

DDV.on("info", (e) => {  
    // init loadSource save filter perspective loadWasm
    if(e.status === "Pending")
      Dynamsoft_Ref.Lib.showMask(); //'Pending'
    else if(e.status === "Completed" || e.status === "Failed" || e.status === "Canceled")
      Dynamsoft_Ref.Lib.hideMask();
});

async function initLoad() {
    let file1 = await (await fetch(resourceRoot + '/files/test.pdf?t=' + timestamp)).blob();
     await DDVExperimentsTool.ddvObject.loadSource(file1);
     DDVExperimentsTool.editViewer.goToPage(0);
    initDefaultStamp();
}
function initDefaultStamp() {
  let default_stamp_url = `${DDV_ImagePath}/DRAFT.png`;
  default_stamp_obj = {
    data: "SBDraft",
    type: 'system'
  };
  let stampDropDownEl = document.querySelector('.ds-stamp-dropdown img') as HTMLImageElement;
  if (stampDropDownEl) {
    stampDropDownEl.src = default_stamp_url;
    stampDropDownEl.setAttribute('data', default_stamp_obj.data);
  }
}
// select first sign
async function initDefaultSign() {
    let signStampDropDownEl = document.querySelector('.ds-stamp-sign-dropdown img') as HTMLImageElement;
    if (signStampDropDownEl) {
      let presetObj = insertMenu_sign.presetEls[0];
      let imgs = $(presetObj.wrapperEl).find('.ddv-sign-button img');
      if (imgs.length > 0) {
        let _img = imgs[0], _id = _img.id;

        if(_id != '') {
          signStampDropDownEl.id = _id;
          default_sign_imgBlob = inkSignatureImageMap[_id];
          signStampDropDownEl.src = _img.src;
          return;
        }
      }
    }
    default_sign_imgBlob = null;
    signStampDropDownEl.src = BLANK_SIGN_IMAGE_URL;
    cancelSignHandler();
}
async function onClickSign(evt) {
    let el = evt.target;
    evt.stopPropagation();
    $('.ddv-popup-dialog').hide();

    let _id = el.id;
    if(_id != '' && inkSignatureImageMap[_id]) {
      default_sign_imgBlob = inkSignatureImageMap[_id];
    } else {
      console.error('error get signature config');
      return;
    }

    if (el.src == BLANK_SIGN_IMAGE_URL) {
      return;
    }

    let signImage = document.querySelector('.ds-stamp-sign-dropdown img') as HTMLImageElement;
    if (signImage && signImage != el) {
      signImage.id = el.id;
      signImage.src = el.src;
    }
    DDVExperimentsTool.editViewer.toolMode = 'annotation';
    DDVExperimentsTool.editViewer.setAnnotationDrawingStyle({
      stamp: {
        stamp: default_sign_imgBlob
      }
    });
    DDVExperimentsTool.editViewer.annotationMode = "stamp";
}
async function createNewSignHandler() {

    default_sign_imgBlob = await inkSignatureBoard.getSignatureImage();
    if(!default_sign_imgBlob) {
      // same as cancel
      cancelSignHandler();
      return;
    }

    const newImageId = tools.genUUID();
    inkSignatureImageMap[newImageId] = default_sign_imgBlob;

    let url1 = URL.createObjectURL(default_sign_imgBlob);

    const signsContainer = $('.ddv-signs-container');
    let newSignDiv = document.createElement('div');
    newSignDiv.className = 'ddv-stamp-sign';
    let signButton = document.createElement('button');
    signButton.className = 'ddv-sign-button';
    let signImage = new Image();
    signImage.id = newImageId;
    signImage.src = url1;
    signImage.draggable = false;
    signButton.append(signImage);
    $(signImage).on('click', evt => onClickSign(evt));
    newSignDiv.append(signButton);
    let signImageDel = new Image();
    signImageDel.draggable = false;
    signImageDel.src = `${DDV_ImagePath}/trash.png`;
    let signButtonDel = document.createElement('button');
    signButtonDel.className = 'ddv-sign-remove';
    signButtonDel.append(signImageDel);
    newSignDiv.append(signButtonDel);
    signsContainer.append(newSignDiv);
    const signsContainerEl = document.querySelector('.ddv-signs-container') as HTMLElement,
      popupDialogEl = document.querySelector('.ddv-popup-dialog') as HTMLElement,
      bNotDisplay = popupDialogEl.style.display === 'none';
    if (bNotDisplay) {
      popupDialogEl.style.display = '';
    }
    signsContainerEl.scrollBy(0, signsContainerEl.scrollHeight);
    if (bNotDisplay) {
      popupDialogEl.style.display = 'none';
    }
    $(signButtonDel).on('click', evt => onClickSignDel(evt));
    let defaultSignImg = document.querySelector('.ds-stamp-sign-dropdown img') as HTMLImageElement;
    if (defaultSignImg) {
      defaultSignImg.id = newImageId;
      defaultSignImg.src = url1;
    }
    createNewSign(default_sign_imgBlob);
}
async function onClickSignDel(evt) {
    let elDel = evt.target;
    evt.stopPropagation();
    let p = $(elDel).parent();
    let _url = p.find('.ddv-sign-button img').attr('src');
    p.remove();
    URL.revokeObjectURL(_url);
    let signStampDropDownEl = document.querySelector('.ds-stamp-sign-dropdown img') as HTMLImageElement;
    if (signStampDropDownEl && signStampDropDownEl.src == _url) {
      // select first sign
      await initDefaultSign();
    }
}
function createNewSign(sign_config) {
  setIgnoreAnnotationDefaultStyleChanged();
  DDVExperimentsTool.editViewer.toolMode = 'annotation';
  DDVExperimentsTool.editViewer.setAnnotationDrawingStyle({
    stamp: {
      stamp: sign_config
    }
  });
  DDVExperimentsTool.editViewer.annotationMode = "stamp";

  let divDDVSign = $('.ddv-sign');
  divDDVSign.hide();
  $(document.body).append(divDDVSign);
  UI.CloseMessage();
}
function clickCurrentSelectedMenu() {
  let curViewerName = lastSelected.viewer,
    lastAnnotationMenu;
  if (curViewerName != '') {
    lastAnnotationMenu = lastSelected[curViewerName];
  }
  if (lastAnnotationMenu) {
    $(lastAnnotationMenu.getElButton()).click();
  }
}
function cancelSignHandler() {
  let divDDVSign = $('.ddv-sign');
  divDDVSign.hide();
  $(document.body).append(divDDVSign);
  UI.CloseMessage();
  let presetObj = insertMenu_sign.presetEls[0];
  if (presetObj.isSignsEmpty) {
    insertMenu_sign.setInActive();
    if (preSignAnnotationMenu && preSignAnnotationMenu != insertMenu_sign) {
      preSignAnnotationMenu.setActive();
      lastSelected.insert = preSignAnnotationMenu;
    } else {
      insertMenu_Select.setActive();
      lastSelected.insert = insertMenu_Select;
    }
    resetPreset(lastSelected.insert);
    clickCurrentSelectedMenu();
  }
}
function cancelNewStampHandler() {
  let divDDVStamp = $('.ddv-new-stamp');
  divDDVStamp.hide();
  $(document.body).append(divDDVStamp);
  UI.CloseMessage();
}
async function onClickStampDel(evt) {
    let elDelButton = evt.target;
    evt.stopPropagation();
    let p = $(elDelButton).parent();
    let _url = p.find('.ddv-custom-stamp img').attr('src');
    p.remove();
    URL.revokeObjectURL(_url);
    let stampDropDownEl = document.querySelector('.ds-stamp-dropdown img') as HTMLImageElement;
    if (stampDropDownEl && stampDropDownEl.src == _url) {
      initDefaultStamp();
    }
}
function createNewStampHandler(evtNewStamp) {
  redrawStamp(evtNewStamp.target);
  const stamp_canvas = stampSignatureBoard.getCanvas();
  stamp_canvas.toBlob(function (_newBlob) {
    if (!_newBlob) return;

    const stampConfig = stampSignatureBoard.getStampConfig();
    const signatureStyle = stampSignatureBoard.signatureStyle;
    const _url = URL.createObjectURL(_newBlob);
    const stampsContainer = $('.ddv-custom-stamps-container');
    let newCustomStampDiv = document.createElement('div');
    let stampButton = document.createElement('button');
    stampButton.className = 'ddv-custom-stamp';
    let stampImage = new Image();
    stampImage.draggable = false;
    // generate image id, put to map
    const newImageId = tools.genUUID();
    stampImage.id = newImageId;
    stampImageMap[newImageId] = signatureStyle;
    stampImage.src = _url;
    stampImage.setAttribute('data', newImageId);
    stampButton.append(stampImage);
    $(stampImage).on('click', evt => onClickStamp_new(evt));
    newCustomStampDiv.append(stampButton);
    let stampImageDel = new Image();
    stampImageDel.draggable = false;
    stampImageDel.src = `${DDV_ImagePath}/trash.png`;
    let stampButtonDel = document.createElement('button');
    stampButtonDel.className = 'ddv-custom-stamp-remove';
    stampButtonDel.append(stampImageDel);
    newCustomStampDiv.append(stampButtonDel);
    stampsContainer.append(newCustomStampDiv);
    const customStampsContainerEl = document.querySelector('.ddv-custom-stamps-container'),
      popupDialogEl = document.querySelector('.ddv-popup-dialog') as HTMLElement,
      bNotDisplay = popupDialogEl && popupDialogEl.style.display === 'none';
    if (bNotDisplay) {
      popupDialogEl.style.display = '';
    }
    if (customStampsContainerEl && customStampsContainerEl.scrollHeight > 0) {
      customStampsContainerEl.scrollBy(0, customStampsContainerEl.scrollHeight);
    }
    if (bNotDisplay) {
      popupDialogEl.style.display = 'none';
    }
    $(stampButtonDel).on('click', evt => onClickStampDel(evt));
    let stampDropDownEl = document.querySelector('.ds-stamp-dropdown img') as HTMLImageElement;
    stampDropDownEl.id = newImageId;
    stampDropDownEl.src = _url;
    stampDropDownEl.setAttribute('data', newImageId);
    createNewStamp(stampConfig);
  }, 'png');
}
function createNewStamp(_config) {
  setIgnoreAnnotationDefaultStyleChanged();
  default_stamp_obj = {
    data: '',
    type: 'custom',
    config: _config
  };
  DDVExperimentsTool.editViewer.toolMode = 'annotation';
  DDVExperimentsTool.editViewer.setAnnotationDrawingStyle({
      stamp: {
        stamp: _config
      }
  });
  DDVExperimentsTool.editViewer.annotationMode = "stamp";
  let divDDVStamp = $('.ddv-new-stamp');
  divDDVStamp.hide();
  $(document.body).append(divDDVStamp);
  UI.CloseMessage();
}

function createDWTObject(callback) {
  Dynamsoft_Ref.DWT.ProductKey = environment.Dynamsoft.dwtProductKey;
  Dynamsoft_Ref.DWT.ServiceInstallerLocation = 'https://demo.dynamsoft.com/DWT/Resources/dist';
  //Dynamsoft_Ref.DWT.ResourcesPath = 'Resources';
  Dynamsoft_Ref.DWT.CreateDWTObjectEx({
    WebTwainId: 'ds_dwt_id',
  },function (object) {
    DWTObject = object;
    DWTObject.RegisterEvent("OnPostTransferAsync", Dynamsoft_OnPostTransferAsync);
    DWTObject.RegisterEvent("OnPostAllTransfers", Dynamsoft_OnPostAllTransfers);
    if(callback) callback();
  }, function (error) {
    console.log(error);
  });
}

function downloadDialog() {

  let divSaveDialog = $('.ddv-save-dialog');
  closePopUI();
  UI.ShowMessage(divSaveDialog, {
    headerStyle: 0
  });
  divSaveDialog.show();

  (document.querySelector('.ds-ddv-save-input-Indices') as HTMLElement).addEventListener('focus', function(evt){
    let notCheckedEl = document.querySelector('input[name="radioIndeciesType"]:not(:checked)') as HTMLInputElement;
    if(notCheckedEl.value == 'custom') {
      notCheckedEl.checked = true;
    }
  });

}

function click(node) {
  try {
    node.dispatchEvent(new MouseEvent("click"));
  } catch (e) {
    const evt = document.createEvent("MouseEvents");
    evt.initMouseEvent(
      "click",
      true,
      true,
      window,
      0,
      0,
      0,
      80,
      20,
      false,
      false,
      false,
      false,
      0,
      null,
    );
    node.dispatchEvent(evt);
  }
}

function parseIndex(input, MacCount) {
    let result:any = [];
    const parts = input.split(',');

    parts.forEach(part => {
        if (part.includes('-')) {
            const range = part.split('-');
            const start = parseInt(range[0], 10);
            const end = parseInt(range[1], 10);

            // Boundary checks for range
            if (start <= 0 || start > MacCount || end <= 0 || end > MacCount) {
                alert('Error: Custom indices must be between 1 and ' + MacCount);
                result = [];
                return; // Exit the function if an invalid range is detected
            }

            for (let i = start; i <= end; i++) {
                if (i <= 0 || i > MacCount) {
                    alert('Error: Custom indices must be between 1 and ' + MacCount);
                    result = [];
                    return; // Exit the function if an invalid index is detected
                }
                result.push(i - 1); // Assuming 0-based indexing
            }
        } else {
            const index = parseInt(part, 10);

            // Boundary check for individual values
            if (index <= 0 || index > MacCount) {
                alert('Error: Custom indices must be between 1 and ' + MacCount);
                result = [];
                return; // Exit the function if an invalid value is detected
            }

            result.push(index - 1); // Assuming 0-based indexing
        }
    });

    return result;
}

async function action_DownloadDialog(name, savePdfSettings) {

  try{
    if(DDVExperimentsTool.editViewer.currentDocument.pages.length == 0){
      alert("There is no image in the current document.");
      return false
    }
    Dynamsoft_Ref.Lib.showMask();

    const _a = document.createElementNS("http://www.w3.org/1999/xhtml", "a") as HTMLAnchorElement;

    let indecies = [], bCheckAll = false;
    let indeciesTypeEl = document.querySelector('input[name="radioIndeciesType"]:checked') as HTMLInputElement;
    if(indeciesTypeEl) {
      if(indeciesTypeEl.value === 'all') {
        bCheckAll = true;
      } else {
        bCheckAll = false;
        try{
          indecies = parseIndex($('.ds-ddv-save-input-Indices').val(), DDVExperimentsTool.editViewer.currentDocument.pages.length);  //JSON.parse('[' + $('.ds-ddv-save-input-Indices').val() + ']');
        }catch(_){}
      }
    }

    if(bCheckAll == false && indecies.length ==0)
      return false;

    let _blob;
    if(bCheckAll)
      _blob = await DDVExperimentsTool.ddvObject.saveToPdf(savePdfSettings);
    else {
      _blob = await DDVExperimentsTool.ddvObject.saveToPdf(indecies, savePdfSettings);
    }

    _a.download =  name;
    _a.rel = "noopener"; // tabnabbing

    _a.href = URL.createObjectURL(_blob);
    setTimeout(() => { click(_a); }, 0);
    setTimeout(() => {
      URL.revokeObjectURL(_a.href);
      _a.href = "";
      _a.remove();
    }, 500);

     return true;

  }catch(ex){}
  finally{
    Dynamsoft_Ref.Lib.hideMask();
  }

}

function initSaveDialog() {
  
  /*
  $('.ds-save-options-fileType').on('change', function(evt){

    let v = evt.target.value;
    
    $('.ds-save-jpg-options').hide();
    $('.ds-save-tiff-options').hide();
    $('.ds-save-pdf-options').hide();

    if(v === 'png') {}
    else if(v === 'jpg') {$('.ds-save-jpg-options').show();}
    else if(v === 'tiff') {$('.ds-save-tiff-options').show();}
    else if(v === 'pdf') {$('.ds-save-pdf-options').show();}
    
  });

  $('.ds-save-options-tiff-compression').on('change', function(evt){
    let v = evt.target.value, jpgQualityEl = $('.ds-save-tiff-jpeg-quality').getEl();
    if(jpgQualityEl) {
      if(v === 'tiff/jpeg') {jpgQualityEl.disabled = false}
      else {jpgQualityEl.disabled = true}
    }
  });
  $('.ds-save-options-pdf-compression').on('change', function(evt){
    let v = evt.target.value, jpgQualityEl = $('.ds-save-pdf-jpeg-quality').getEl();

    if(jpgQualityEl) {
      if(v === 'pdf/jpeg') {jpgQualityEl.disabled = false}
      else if(v === 'pdf/jp2000') {jpgQualityEl.disabled = false}
      else {jpgQualityEl.disabled = true}
    }
  });
  */
  $('.ds-button-save-file').on('click', function(evt){

    let result = false;
    let fileName = $('.ds-save-options-fileName').val();
    let fileType = 'pdf';
    //let fileType = $('.ds-save-options-fileType').val();
    //let bAnnotation = $('.ds-save-options-Annotation').getEl().checked;
    
    if(fileType === 'png') {}
    else if(fileType === 'jpg') {
      //let quality = $('.ds-save-jpeg-quality').val();
    }
    else if(fileType === 'tiff') {
      //let quality = $('.ds-save-tiff-jpeg-quality').val();
      //let tiffCompression = $('.ds-save-options-tiff-compression').val();
    }
    else if(fileType === 'pdf') {
      let password = $('.ds-save-options-password').val();
      let pageType = $('.ds-save-options-pdf-pagesize').val();
      let savetype = $('.ds-save-options-pdf-savetype').val();
      //let pdfCompression = $('.ds-save-options-pdf-compression').val();
      //let quality = $('.ds-save-pdf-jpeg-quality').val();

      let settings;

      settings = {
        mimeType: "application/octet-stream",
        saveAnnotation: savetype,
        pageType: pageType
      };

      if(password) {
        settings.password = password;
      }
      
      action_DownloadDialog(fileName + '.pdf', settings).then(function(result){
          if(result) {
            let divSaveDialog = $('.ddv-save-dialog');
            divSaveDialog.hide();
            $(document.body).append(divSaveDialog);
            closePopUI();
          }
      });
    }
  });
  
  $('.ds-button-cancel-save').on('click', function(evt){
    let divSaveDialog = $('.ddv-save-dialog');
    divSaveDialog.hide();
    $(document.body).append(divSaveDialog);
    closePopUI();
  });
  
  $('.ds-button-password-ok').on('click', function(evt){
    let divPdfPasswordDialog = $('.ddv-pdf-password-dialog');
    divPdfPasswordDialog.hide();
    $(document.body).append(divPdfPasswordDialog);
    closePopUI();
    
    let password = (document.querySelector('.ddv-pdf-password-dialog-password') as HTMLInputElement).value;
    password_resolve(password);
    password_resolve = null;
  });

  $('.ds-button-password-cancel').on('click', function(evt){
    let divPdfPasswordDialog = $('.ddv-pdf-password-dialog');
    divPdfPasswordDialog.hide();
    $(document.body).append(divPdfPasswordDialog);
    closePopUI();
    password_resolve(null);
    password_resolve = null;
  });

}


let password_resolve:any = null;
function inputPassword(fileName?) {
  password_resolve = null;
  return new Promise(function(resolve, reject){
    
    password_resolve = resolve;
    let divPdfPasswordDialog = $('.ddv-pdf-password-dialog');
    closePopUI();
    UI.ShowMessage(divPdfPasswordDialog, {
      headerStyle: 0
    });
    const jqTips = $('.ddv-pdf-password-dialog-tips');
    if(fileName) {
      jqTips.html('Enter the password to open the PDF file "' + fileName + '"'); 
    } else {
      jqTips.html('Enter the password to open this PDF file.'); 
    }
    
    let passwordEl = document.querySelector('.ddv-pdf-password-dialog-password') as HTMLInputElement;
    
    passwordEl.value = '';
    divPdfPasswordDialog.show();
    passwordEl.focus();
  
  });
}

async function _loadFiles(files) {
  
  if(!files || files.length == 0)
    return;

    let n:any = [];
    const len = files.length, passwordErrorEl = document.querySelector('.ddv-pdf-password-dialog-error') as HTMLInputElement;

    for (let i = 0; i < len; i++) {
      const _file = files[i];
      const _blob = new Blob([_file],{type: _file.type});
      if ("application/pdf" === _file.type) {
        const fileName = _file.name;
        const n1:any = [{
              fileData: _blob,
              convertMode: DDV.EnumConvertMode.CM_AUTO,
              renderOptions: {
                renderAnnotations: DDV.EnumAnnotationRenderMode.LOAD_ANNOTATIONS
              }
            }];

        passwordErrorEl.style.visibility="hidden";
        let password:any = '';
        do{
          try{
            if(password) {
              n1[0].password = password;
            }
            await DDVExperimentsTool.ddvObject.__rawLoadSource(n1);
            break;
          }catch(_exp){
            
            DDVExperimentsTool.editFullViewer.context.isLoadSource = false;
            DDVExperimentsTool.thumbnailFullViewer.context.isLoadSource = false;
  
            if(_exp && _exp.cause && (-80202 === _exp.cause.code)) {
              password = await inputPassword(fileName);
              if(password !== null) {
                passwordErrorEl.style.visibility="";
                continue;
              }
              break;
            }
            throw _exp;
          }
        }while(true);
        
      } else
        n.push({
          fileData: _blob
        });
    }
    
    if(n.length>0) {
      await DDVExperimentsTool.ddvObject.__rawLoadSource(n); 
    }

    n = null;
}

function wrapperLoadImage(_DDVObj) {

  if(_DDVObj && _DDVObj.loadSource) {
    _DDVObj.__rawLoadSource = _DDVObj.loadSource;
    _DDVObj.loadSource = async function(p1, p2) { 
    
      const passwordErrorEl = document.querySelector('.ddv-pdf-password-dialog-error') as HTMLElement;
      passwordErrorEl.style.visibility="hidden";
      let password:any = '';
      do{
        try{
          if(password && p1) {
            
            if(tools.isArray(p1) && p1.length>0) {
              p1[0].password = password; 
            } else if (p1 && "application/pdf" === p1.type) {
              p1 = [{
                  fileData: p1,
                  convertMode: DDV.EnumConvertMode.CM_AUTO,
                  renderOptions: {
                    renderAnnotations: DDV.EnumAnnotationRenderMode.LOAD_ANNOTATIONS
                  }, 
                  password: password
                }];
            }
          }
          await _DDVObj.__rawLoadSource(p1, p2);
          break;
        }catch(_exp){
          
          DDVExperimentsTool.editFullViewer.context.isLoadSource = false;
          DDVExperimentsTool.thumbnailFullViewer.context.isLoadSource = false;

          if(_exp && _exp.cause && (-80202 === _exp.cause.code)) {
            password = await inputPassword();
            if(password !== null) {
              passwordErrorEl.style.visibility="";
              continue;
            }
            break;
          }
          throw _exp;
        }
      }while(true);
    
    };
  
    let dom = DDVExperimentsTool.editFullViewer.context.viewService.defaultDom;
    dom.addEventListener('drop', async function(event) {
      event.preventDefault();
      const files = event.dataTransfer.files;
      await _loadFiles(files);
    });
    dom.addEventListener('dragenter', function(event) {
      event.preventDefault();
    });
    dom.addEventListener('dragleave', function(event) {
      event.preventDefault();
    });
    dom.addEventListener('dragover', function(event) {
      event.preventDefault();
    });
            
  }

}

let DWTObject, deviceList;

async function openScanDialog() {
  
  if (DWTObject) {

    if(scan_status.scan_start) {
      console.log('scanning...');
      return;
    }
    
    //if(!scan_status.all_processed) {
    //  console.log('processing...');
    //  return;
    //}

    if(!deviceList) {
      (getEl('source') as HTMLSelectElement).options.length = 0;
      deviceList = await DWTObject.GetDevicesAsync();
      let i;
      for (i = 0; i < deviceList.length; i++) { // Get how many sources are installed in the system
        (getEl('source') as HTMLSelectElement).options.add(new Option(deviceList[i].displayName, i)); // Add the sources in a drop-down list
      }
    }
    
    if(ddvScanDialog) ddvScanDialog.dialog("open");
  } else {
    createDWTObject(openScanDialog);
  }

}

function clickToolbarScanButton() {
  openScanDialog();
}

/*-----------------Acquire Image---------------------*/

function scanButtonClickHandler() {

  if(scan_status.scan_start) {
    console.log('scanning...');
    return;
  }

  if(ddvScanDialog) ddvScanDialog.dialog("close");

  let cIndex = (getEl('source') as HTMLSelectElement).selectedIndex;
  if (cIndex < 0)
    return;

  let i, iPixelType = 0;
  for (i = 0; i < 3; i++) {
    if ((document.getElementsByName('PixelType').item(i) as HTMLInputElement).checked == true)
      iPixelType = i;
  }

  // show mask
  DWTObject.SelectDeviceAsync(deviceList[cIndex]).then(function () {
    appendMessage('Scan: ');
    scan_status.scan_start = true;
    scan_status.all_scaned = false;
    scan_status.all_processed = false;
    
    return DWTObject.AcquireImageAsync({
      IfCloseSourceAfterAcquire: true,
      IfShowUI: (getEl('ShowUI') as HTMLInputElement).checked,
      PixelType: iPixelType,
      Resolution: (getEl('Resolution') as HTMLInputElement).value,
      IfFeederEnabled: (getEl('ADF') as HTMLInputElement).checked,
      IfDuplexEnabled: (getEl('Duplex') as HTMLInputElement).checked,
      IfAutoDiscardBlankpages: (getEl('DiscardBlankPage') as HTMLInputElement).checked,
      IfDisableSourceAfterAcquire: true // Scanner source will be disabled/closed automatically after the scan.
    });
  }).then(function () {
    // hide mask
    checkErrorStringWithErrorCode(0, 'Successful.');
  }).catch(function (exp) {
    // hide mask
    console.log(exp);
    checkErrorStringWithErrorCode(-1, exp.message);
    scan_status.scan_start = false;
    scan_status.all_scaned = false;
    scan_status.all_processed = true;
    DWTObject.CloseSourceAsync();
  });
  
}

function appendMessage(str?) {

}

function checkErrorStringWithErrorCode(code?, message?) {
  
}

let scan_status = {
  scan_start: false,
  all_scaned: false,
  all_processed: true
};

function Dynamsoft_OnPostAllTransfers() {
  scan_status.scan_start = false;
  if(DWTObject.ErrorCode == 0) {
    scan_status.all_scaned = true;
    if(scanned_buffer_pages == 0) {
      scan_status.all_processed = true;
    }
  } else {
    scan_status.all_scaned = false;
    scan_status.all_processed = true;
  }
}

let scanned_buffer_pages = 0;

async function Dynamsoft_OnPostTransferAsync(imageInfo) {

  scanned_buffer_pages++;
  if(scanned_buffer_pages == 1) {
    setTimeout(get_image, 100);
  }
}

async function get_image() {
  
  if(scanned_buffer_pages>0) {
    //console.log('get_image(): get_image start:'+scanned_buffer_pages);
    scanned_buffer_pages--;
    const url = DWTObject.GetImageURL(0);
    const res = await fetch(url);
    const _blob = await res.blob();
    await DDVExperimentsTool.ddvObject.__rawLoadSource({
      fileData: _blob
    });
    
    DWTObject.RemoveImage(0);

    if(scanned_buffer_pages == 0) {
      if(scan_status.all_scaned) {
        scan_status.all_processed = true;
      }
    } else {
      // next
      setTimeout(get_image, 100);
    }
  }
}
