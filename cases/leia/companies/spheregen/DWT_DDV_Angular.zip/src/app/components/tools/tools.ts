
let FALSE = !1,
  nil;
function each(object, fn, context?) {
  if (object) {
    let val,
      i = 0,
      length = object.length;
    for (val = object[0]; i < length; val = object[++i]) {
      if (fn.call(context, val, i, object) === FALSE) {
        break;
      }
    }
  }
  return object;
}
const class2TypeMap = {
  '[object Function]': 'function',
  '[object String]': 'string',
  '[object Object]': 'object',
  '[object Boolean]': 'boolean',
  '[object Number]': 'number',
  '[object Array]': 'array'
};
function getType(o) {
  if (isNull(o) || isNil(o)) return String(o);
  return class2TypeMap[{}.toString.call(o)] || 'object';
}
function isFunction(o) {
  return getType(o) === "function";
}
function isNumber(o) {
  return getType(o) === "number";
}
function isString(o) {
  return getType(o) === "string";
}
function isObject(o) {
  return getType(o) === "object";
}
function isBoolean(o) {
  return getType(o) === "boolean";
}
function isNull(o) {
  return o === null;
}
function isNil(o) {
  return o === nil;
}
function isDef(o) {
  return o !== nil;
}
function isArray(o) {
  if (Array.isArray) {
    return Array.isArray(o);
  }
  return getType(o) === "array";
}
const AP = Array.prototype;
function indexOf(item, arr) {
  return AP.indexOf.call(arr, item);
}
function getHexRandom(bits) {
  return Math.random().toString(16).substring(2, 2 + bits);
}
// gen uuid like 'f813acb4-0b62-47b1-8cff-b1c6413a' 8-4-4-4-8
function genUUID(prefix?) {
  let s = [getHexRandom(8), '-', getHexRandom(4), '-', getHexRandom(4), '-', getHexRandom(4), '-', getHexRandom(8)];
  if (prefix) s.unshift(prefix);
  return s.join('');
}

export const tools = {
  isFunction,
  isNumber,
  isString,
  isObject,
  isBoolean,
  isArray,
  isNull,
  isNil,
  isDef,
  indexOf,
  each,
  addEventListener: function (obj, eventName, eventFun) {
    obj.addEventListener(eventName, eventFun);
  },
  removeEventListener: function (obj, eventName, eventFun) {
    obj.removeEventListener(eventName, eventFun);
  },
  error: function (msg) {
    console.error(msg);
  },
  log: function (msg) {
    console.log(msg);
  },
  genUUID
};
