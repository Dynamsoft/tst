import { DDVExperimentsTool, Dynamsoft_Ref } from "../../../globalObjects";
import { lastSelected } from "../../../menu/lastMenu";
import { elHide, elShow } from "./common";
import { $ } from "src/app/components/tools/simpleJQ";

const dialog = (Dynamsoft_Ref.Lib as any).dialog;
let divMask:any = document.createElement('div') as HTMLElement;
divMask.style.display = 'none';
document.body.appendChild(divMask);

let bShowPalette = false;
export function showPalette() {
  bShowPalette = true;
  let _left = $('.ddv-palette-box').css('left'),
    _top = $('.ddv-palette-box').css('top');
  // save old offset
  if (_left && _left !== '' && _top && _top !== '') {
    let _strOldOffset = JSON.stringify({
      l: _left,
      t: _top
    });
    $('.ddv-palette-box').attr('old-offset', _strOldOffset);
  }
  recalculatePalettePos();
  showPaletteMask();
  let newZIndex = '' + (parseInt(divMask.style.zIndex) + 1);
  let divPresets = document.querySelector('.ds-div-presets') as HTMLElement;
  divPresets.style.zIndex = newZIndex;
  let divPaletteBox = document.querySelector('.ddv-palette-box') as HTMLElement;
  divPaletteBox.style.zIndex = newZIndex;
  $('.ds-icon-dropdown.ds-collapse').removeClass('ds-collapse').addClass('ds-expand');
}
export function hidePalette() {
    var ddvPaletteBox = document.querySelector('.ddv-palette-box') as HTMLElement;
    if(ddvPaletteBox) {
        elHide(ddvPaletteBox);
        (ddvPaletteBox as any).dataset.enableDrag = true;
    }
  $('.ds-icon-dropdown.ds-expand').removeClass('ds-expand').addClass('ds-collapse');
  let _strSavedOffset = $('.ddv-palette-box').attr('old-offset');
  if (bShowPalette) {
    // && $('.ddv-palette-box').css('top') == '-8px' 
    if (_strSavedOffset && _strSavedOffset !== '') {
      let _objOffset = JSON.parse(_strSavedOffset);
      $('.ddv-palette-box').css('left', _objOffset.l);
      $('.ddv-palette-box').css('top', _objOffset.t);
    } else {
      $('.ddv-palette-box').css('left', '');
      $('.ddv-palette-box').css('top', '');
    }
    $('.ddv-palette-box').attr('old-offset', '');
  }
  bShowPalette = false;
  hidePaletteMask();
}
export function isShowPalette() {
  return bShowPalette;
}

function showPaletteMask() {
  dialog.setup(divMask, false);
  divMask.style.display = '';
  divMask.showModal();
  $('.dynamsoft-backdrop').on('click', () => {
    hidePalette();
  });
}
function hidePaletteMask() {
  divMask.style.display = 'none';
  if (divMask.close) divMask.close();
}
function recalculatePalettePos() {
  let curViewerName = lastSelected.viewer,
    lastAnnotationMenu;
  if (curViewerName != '') {
    lastAnnotationMenu = lastSelected[curViewerName];
  }
  let mode = '';
  if (lastAnnotationMenu) {
    mode = lastAnnotationMenu.getElData();
  }
  if (mode == 'image') {
    return;
  }
  
  let ddvPaletteBox = document.querySelector('.ddv-palette-box') as HTMLElement;
  if(ddvPaletteBox) {
    elShow(ddvPaletteBox);
    (ddvPaletteBox as any).dataset.enableDrag = false;
  }

  let _main_container = $('.ddv-main-container').last();
  let _main_container_offset = _main_container.offset();

  
  let toolMode = lastAnnotationMenu.getElDataToolMode();
  DDVExperimentsTool.editViewer.toolMode = toolMode;
  if(toolMode == 'annotation') {
    DDVExperimentsTool.editViewer.annotationMode = mode;
  }
  // set new offset
  let _offset = $('.ds-div-presets').offset();
  if(_offset && _main_container_offset) {
    $('.ddv-palette-box').css('left', _offset.left - _main_container_offset.left);
  }
  $('.ddv-palette-box').css('top', '-6px');
}
window.addEventListener('resize', function (evt) {
  if (bShowPalette) {
    recalculatePalettePos();
  }
});
