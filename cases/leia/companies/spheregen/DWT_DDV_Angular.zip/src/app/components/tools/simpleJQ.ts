import { tools } from "./tools";

function dir(elem, dir) {
  let matched:any = [],
    cur = elem[dir];
  while (cur && cur.nodeType !== 9) {
    if (cur.nodeType === 1) {
      matched.push(cur);
    }
    cur = cur[dir];
  }
  return matched;
}

export class simpleJQ {

  length;

  constructor(selector, context?) {
    let nodeList:any = [];
    if (selector) {
      if (typeof selector == 'string') {
        nodeList = (context || document).querySelectorAll(selector);
      } else if (selector instanceof Node) {
        nodeList[0] = selector;
      } else if (selector instanceof NodeList || selector instanceof Array || selector.length > 0) {
        nodeList = selector;
      }
    }
    this.length = nodeList.length;
    for (let i = 0; i < this.length; i += 1) {
      this[i] = nodeList[i];
    }
  }
  each(cb_fun, need_ret?) {
    let res:any = [];
    for (let i = 0; i < this.length; i++) {
      res[i] = cb_fun.call(this[i], i, this[i]);
    }
    if (need_ret) {
      if (res.length == 1) {
        res = res[0];
      }
      return res;
    }
    return this;
  }
  eq(index) {
    return new simpleJQ([this[index]]);
  }
  first() {
    return this.eq(0);
  }
  last() {
    return this.eq(this.length - 1);
  }
  find(str) {
    let nodeList:any = [];
    let res = this.each(function () {
      return this.querySelectorAll(str);
    }, 1);
    if (res instanceof Array) {
      for (let i = 0; i < res.length; i++) {
        for (let j = 0; j < res[i].length; j++) {
          nodeList.push(res[i][j]);
        }
      }
    } else {
      nodeList = res;
    }
    return new simpleJQ(nodeList);
  }
  parent() {
    return new simpleJQ(this.each(function () {
      return this.parentNode;
    }, 1));
  }
  hide() {
    return this.each(function () {
      this.style.display = "none";
    });
  }
  show() {
    return this.each(function () {
      this.style.display = "";
    });
  }
  toggle() {
    return this.each(function () {
      if (this.style.display == 'none') this.style.display = "";else this.style.display = "none";
    });
  }
  children() {
    return this.each(function () {
      return new simpleJQ(this.children);
    }, 1);
  }
  text(str) {
    if (str != undefined) {
      return this.each(function () {
        this.innerText = str;
      });
    } else {
      return this.each(function () {
        return this.innerText;
      }, 1);
    }
  }
  html(str) {
    if (str != undefined) {
      return this.each(function () {
        this.innerHTML = str;
      });
    } else {
      return this.each(function () {
        return this.innerHTML;
      }, 1);
    }
  }
  outHtml(str) {
    if (str != undefined) {
      return this.each(function () {
        this.outerHTML = str;
      });
    } else {
      return this.each(function () {
        return this.outerHTML;
      }, 1);
    }
  }
  val(str?) {
    if (str != undefined) {
      return this.each(function () {
        this.value = str;
      });
    } else {
      return this.each(function () {
        return this.value;
      }, 1);
    }
  }
  css(key, value?, important?) {
    if (value != undefined) {
      return this.each(function () {
        let _v = value;
        if (key == 'left' || key == 'top' || key == 'right' || key == 'bottom') {
          if (tools.isNumber(_v)) {
            _v = _v + 'px';
          }
        }
        this.style.setProperty(key, _v, important);
      });
    } else {
      return this.each(function () {
        return this.style.getPropertyValue(key);
      }, 1);
    }
  }
  attr(key, value?) {
    if (value != undefined) {
      return this.each(function () {
        this.setAttribute(key, value);
      });
    } else {
      return this.each(function () {
        return this.getAttribute(key);
      }, 1);
    }
  }
  removeAttr(key) {
    return this.each(function () {
      this.removeAttribute(key);
    });
  }
  remove() {
    return this.each(function () {
      this.remove();
    });
  }
  append(el) {
    return this.each(function () {
      if (el instanceof simpleJQ) {
        let _this = this;
        el.remove();
        el.each(function () {
          _this.append(this);
        });
        return;
      }
      this.append(el);
    });
  }
  hasClass(str) {
    return this.each(function () {
      return this.classList.contains(str);
    }, 1);
  }
  addClass(str) {
    return this.each(function () {
      return this.classList.add(str);
    });
  }
  removeClass(str) {
    return this.each(function () {
      return this.classList.remove(str);
    });
  }
  toggleClass(str) {
    return this.each(function () {
      if (this.classList.contains(str)) return this.classList.remove(str);else return this.classList.add(str);
    });
  }
  on(name, f) {
    if (typeof f == "function") {
      this.each(function () {
        this.addEventListener(name, f);
      });
    }
  }
  click(f?) {
    if (f && typeof f == "function") {
      this.on('click', f);
    } else {
      this.each(function () {
        this.click();
        //let event = document.createEvent('HTMLEvents');
        //event.initEvent("click", true, true);
        //this.dispatchEvent(event);
      });
    }
  }
  parents() {
    return new simpleJQ(this.each(function () {
      return dir(this, "parentNode");
    }, 1));
  }
  offset() {
    var rect,
      win,
      elem = this[0];
    if (!elem) {
      return;
    }
    if (!elem.getClientRects().length) {
      return {
        top: 0,
        left: 0
      };
    }
    rect = elem.getBoundingClientRect();
    win = elem.ownerDocument.defaultView;
    return {
      top: rect.top + win.pageYOffset,
      left: rect.left + win.pageXOffset
    };
  }
  getEl() {
    if(this.length>0)
      return this[0];
    return;
  }
}

export function $(selector, context?) : simpleJQ {
  return new simpleJQ(selector, context);
}
