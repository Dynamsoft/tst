
import { DDVAnnotationMenuSelect } from "../annotation/DDVAnnotationMenuSelect";
import { DDVSVGAnnotationMenuRectangle } from "../annotation/DDVSVGAnnotationMenuRectangle";

export const shapesMenu_Select = new DDVAnnotationMenuSelect();
export const shapesMenu_Rectangle = new DDVSVGAnnotationMenuRectangle('#112233');