import { DDVColorSelector } from "../app/components/tools/colorSelector";
import { CustomStampItem } from "../app/components/tools/FontItem";
import { tools } from "../app/components/tools/tools";
import { DDV } from "dynamsoft-document-viewer";
import { $ } from "src/app/components/tools/simpleJQ";

const customStampBoardClass= DDV.Experiments.get("AnnotationCustomStampBoard");
const stampCanvasWidth = 300, stampCanvasHeight = 120;
export const stampSignatureBoard = new customStampBoardClass(stampCanvasWidth, stampCanvasHeight);

export function createNewStampDialog() {
  const dlgHtml = `<div><h3>Create New Stamp</h3></div>
<div class="mb5">
  <div class="ddv-stamp-canvas-container"></div>
</div>
<div class="ddv-stamp-text-style-container mt20">
  <span class="ddv-stamp-label mr5">Text: </span>
  <span><input class="ddv-stamp-text" type="text" value="Draft" maxlength="40" /></span>
  <span class="ddv-stamp-label ml12 mr5">Text Size: </span>
  <span><select class="ddv-stamp-text-size" value="40"/></select></span>
</div>
<div class="ddv-stamp-font-style-container mt10 ddv-button-display">
  <span class="ddv-stamp-label mr5">Font Style: </span>
  <div class="ddv-button">
    <select class="ddv-custom-stamp-select-font">
      <option value="Arial" selected>Arial</option>
      <option value="Courier">Courier</option>
      <option value="Helvetica">Helvetica</option>
      <option value="Times New Roman">Times New Roman</option>
    </select>
  </div>
  <div class="ddv-button-display ddv-button">
    <div class="ddv-bold"></div>
    <div class="ddv-italic"></div>
    <div class="ddv-underline"></div>
    <div class="ddv-line-through"></div>
  </div>
</div>
<div class="ddv-stamp-buttons-container mt10 ddv-text-color-selector">
  <div>Text Color: </div>
</div>
<div class="ddv-stamp-buttons-container mt10 ddv-border-color-selector">
  <div>Border Color: </div>
</div>
<div class="ddv-stamp-buttons-container mt10 ddv-background-color-selector">
  <div>Background Color: </div>
</div>
<div class="ddv-stamp-buttons-container ddv-stamp-timestamp mt10">
  <div>Timestamp Text: </div>
  <span><input class="ddv-stamp-user" type="text" value="Guest" maxlength="40" /></span>
  <span><label for="ds-ddv-stamp-chk-username"> <input id="ds-ddv-stamp-chk-username" type="checkbox" />Username</label> </span>
  <span><label for="ds-ddv-stamp-chk-date"> <input id="ds-ddv-stamp-chk-date" type="checkbox" />Date</label> </span>
  <span><label for="ds-ddv-stamp-chk-time"> <input id="ds-ddv-stamp-chk-time" type="checkbox" />Time</label> </span>
</div>
<div class="ddv-stamp-buttons-container mt5" style="padding:10px;text-align:right">
  <button class="ddv-button-stamp-create">Create</button>
  <button class="ddv-button-stamp-cancel">Cancel</button>
</div>`;
  let newDiv = document.createElement('div');
  newDiv.className = 'ddv-new-stamp';
  newDiv.style.display = 'none';
  newDiv.innerHTML = dlgHtml;
  document.body.append(newDiv);

  const txtSizeEl = document.querySelector('.ddv-new-stamp .ddv-stamp-text-size') as HTMLSelectElement;
  if(txtSizeEl) {
    const aryFontSize = [11, 12, 14, 16, 18, 20, 22, 24, 28, 36, 40, 48];
    tools.each(aryFontSize, function(val){
      let option = new Option(val, val);
      if(val === 40) {
        option.selected = true;
      }
      txtSizeEl.add(option);
    });
  }

  const stamp_canvas =  stampSignatureBoard.getCanvas();
  $('.ddv-new-stamp .ddv-stamp-canvas-container').append(stamp_canvas);

  let colorChangedEvent = redrawStamp;
  $('.ddv-text-color-selector')?.append(createTextColorSelect(colorChangedEvent));
  $('.ddv-border-color-selector')?.append(createBorderColorSelect(colorChangedEvent));
  $('.ddv-background-color-selector')?.append(createBackgroundColorSelect(colorChangedEvent));
}

let bFontBlod = false,
  bFontItalic = false,
  bFontUnerline = false,
  bFontStrikethrough = false;

let objTextColorSelector, objBackgroundColorSelector, objBorderColorSelector;
function createTextColorSelect(callbackEvent) {
  let maxColorNumber = 12,
    presetColors = ["#47B347", "#4788B3", "#B34947", "#FFFFFF", "#000000"],
    colorButtonClassName = 'ddv-stamp-color';
  objTextColorSelector = new DDVColorSelector(maxColorNumber, presetColors, colorButtonClassName);
  objTextColorSelector.setEventForActiveColorButton(callbackEvent);
  objTextColorSelector.setEventForColorChanged(callbackEvent);
  objTextColorSelector.setActiveColor('#47B347');
  return objTextColorSelector.getEl();
}
function createBorderColorSelect(callbackEvent) {
  let maxColorNumber = 12,
    presetColors = ["#47B347", "#4788B3", "#B34947", "#FFFFFF", "#000000", "transparent"],
    colorButtonClassName = 'ddv-stamp-border-color';
  objBorderColorSelector = new DDVColorSelector(maxColorNumber, presetColors, colorButtonClassName);
  objBorderColorSelector.setEventForActiveColorButton(callbackEvent);
  objBorderColorSelector.setEventForColorChanged(callbackEvent);
  objBorderColorSelector.setActiveColor('#47B347');
  return objBorderColorSelector.getEl();
}
function createBackgroundColorSelect(callbackEvent) {
  let maxColorNumber = 12,
    presetColors = ["#E5FFE5", "#E5F5FF", "#FFE6E5", "#FFFFFF", "#000000", "transparent"],
    colorButtonClassName = 'ddv-stamp-bgcolor';
  objBackgroundColorSelector = new DDVColorSelector(maxColorNumber, presetColors, colorButtonClassName);
  objBackgroundColorSelector.setEventForActiveColorButton(callbackEvent);
  objBackgroundColorSelector.setEventForColorChanged(callbackEvent);
  objBackgroundColorSelector.setActiveColor('#E5FFE5');
  return objBackgroundColorSelector.getEl();
}

function getCustomStampItem() {

  let item = new CustomStampItem();

  item.textColor = $('.ddv-stamp-color.active').attr('value');
  item.backgroundColor = $('.ddv-stamp-bgcolor.active').attr('value');
  item.borderColor = $('.ddv-stamp-border-color.active').attr('value');
  
  let txtEl = (document.querySelector('.ddv-stamp-text') ) as HTMLInputElement;
  let txtSizeEl = document.querySelector('.ddv-stamp-text-size') as HTMLInputElement;
	const selectEl_fontFamily = (document.querySelector('.ddv-custom-stamp-select-font') ) as HTMLInputElement;
  
  let txtUserEl = (document.querySelector('.ddv-stamp-user') ) as HTMLInputElement;
  let chkUserNameEl = (document.getElementById('ds-ddv-stamp-chk-username') ) as HTMLInputElement;
  let chkDateEl = (document.getElementById('ds-ddv-stamp-chk-date') ) as HTMLInputElement;
  let chkTimeEl = (document.getElementById('ds-ddv-stamp-chk-time') ) as HTMLInputElement;


  item.text = txtEl.value;
  item.fontItem.setFontSize(txtSizeEl.value);
  if(selectEl_fontFamily) {
    item.fontItem.fontFamily = selectEl_fontFamily.value;
  }

  if(bFontItalic) {
    item.fontItem.italic = true;
    item.fontItem.fontStyle = "italic";
  } else {
    item.fontItem.italic = false;
    item.fontItem.fontStyle = "normal";
  }

  item.fontItem.bold = bFontBlod;
  item.fontItem.strikethrough = bFontStrikethrough;

  if(bFontUnerline) {
    item.fontItem.underLine = true;
  }

  item.hasUserName = chkUserNameEl.checked;
  if(item.hasUserName) {
    item.userName = txtUserEl.value;
  } else {
    item.userName = "";
  }
  item.hasDate = chkDateEl.checked;
  item.hasTime = chkTimeEl.checked;

  return item;
}

export function redrawStamp(el?, bUpdateStyle?) {
  if (el && $(el).hasClass('ddv-button-palette-color')) {
    $(el).parent().find('.active').removeClass('active');
    $(el).addClass('active');
  }

  if(bUpdateStyle !== false) {
    let _customStampItem = getCustomStampItem();
    if(_customStampItem) {
      stampSignatureBoard.updateSignatureStyle({  
        stampText: _customStampItem.text,
        borderColor:  _customStampItem.borderColor,
        background: _customStampItem.backgroundColor,
        color: _customStampItem.textColor,
        fontSize: _customStampItem.fontItem.fontSize,
        fontFamily: _customStampItem.fontItem.fontFamily,
        fontWeight: _customStampItem.fontItem.bold ? "bold" : "normal",
        fontStyle: _customStampItem.fontItem.fontStyle,
        underline: _customStampItem.fontItem.underLine,     
        strikeout: _customStampItem.fontItem.strikethrough,
        timeStampFontSize: _customStampItem.fontItem.timeStampFontSize,
        userName: _customStampItem.userName,
        hasUserName: _customStampItem.hasUserName,
        hasDate: _customStampItem.hasDate,
        hasTime: _customStampItem.hasTime
      });
    }
  }
}

export function fontStyleChanged(evt) {
  let el = evt.target,
    bActiveNow = false;
  if ($(el).hasClass('active')) {
    $(el).removeClass('active');
    bActiveNow = false;
  } else {
    $(el).addClass('active');
    bActiveNow = true;
  }
  if ($(el).hasClass('ddv-bold')) {
    bFontBlod = bActiveNow;
  } else if ($(el).hasClass('ddv-italic')) {
    bFontItalic = bActiveNow;
  } else if ($(el).hasClass('ddv-underline')) {
    bFontUnerline = bActiveNow;
  } else if ($(el).hasClass('ddv-line-through')) {
    bFontStrikethrough = bActiveNow;
  }
  redrawStamp();
}
