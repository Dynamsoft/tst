
import { DDVAnnotationMenuSelect } from "../annotation/DDVAnnotationMenuSelect";
import { DDVAnnotationMenuStamp } from "../annotation/DDVAnnotationMenuStamp";
import { DDVAnnotationMenuSign } from "../annotation/DDVAnnotationMenuSign";
import { DDVAnnotationMenuImageFileStamp } from "../annotation/DDVAnnotationMenuImageFileStamp";

export const insertMenu_Select = new DDVAnnotationMenuSelect();
export const insertMenu_OpenImageFile = new DDVAnnotationMenuImageFileStamp('#112233');
export const insertMenu_Stamp = new DDVAnnotationMenuStamp();
export const insertMenu_sign = new DDVAnnotationMenuSign();