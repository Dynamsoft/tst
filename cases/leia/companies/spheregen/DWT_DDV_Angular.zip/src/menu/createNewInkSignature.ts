import { DDV } from "dynamsoft-document-viewer";
import { $ } from "src/app/components/tools/simpleJQ";

const inkSignatureBoardClass= DDV.Experiments.get("AnnotationInkSignatureBoard");
const signatureCanvasWidth = 640, signatureCanvasHeight = 400;
export const inkSignatureBoard = new inkSignatureBoardClass(signatureCanvasWidth, signatureCanvasHeight);

export function createNewInkSignatureDialog() {

  const inkSignature_canvas =  inkSignatureBoard.getCanvas();
  inkSignature_canvas.className = 'ddv-graphbox';
  $('.ddv-sign .ddv-ink-signature-canvas-container').append(inkSignature_canvas);

}
