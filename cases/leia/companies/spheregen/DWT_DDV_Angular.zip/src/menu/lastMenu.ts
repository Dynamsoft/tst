
import { DDVAnnotationMenuSelect } from "../annotation/DDVAnnotationMenuSelect";
import { DDVAnnotationHighlightMode } from "../annotation/DDVAnnotationHighlightMode";
import { DDVAnnotationMenuInk } from "../annotation/DDVAnnotationMenuInk";
import { DDVAnnotationMenuLine } from "../annotation/DDVAnnotationMenuLine";
import { DDVAnnotationMenuPolyline } from "../annotation/DDVAnnotationMenuPolyline";
import { DDVAnnotationMenuTextBox } from "../annotation/DDVAnnotationMenuTextBox";
import { DDVAnnotationStrikeoutMode } from "../annotation/DDVAnnotationStrikeoutMode";
import { DDVAnnotationUnderlineMode } from "../annotation/DDVAnnotationUnderlineMode";
import { DDVSVGAnnotationMenuEllipse } from "../annotation/DDVSVGAnnotationMenuEllipse";
import { DDVSVGAnnotationMenuPolygon } from "../annotation/DDVSVGAnnotationMenuPolygon";
import { annotationMenu_Select, annotationMenu_TextTypeWriter } from "./annotationMenu";
import { DDVAnnotationMenuErase } from "../annotation/DDVAnnotationMenuErase";
import { insertMenu_OpenImageFile, insertMenu_Select, insertMenu_sign, insertMenu_Stamp } from "./insertMenu";
import { shapesMenu_Rectangle, shapesMenu_Select } from "./shapesMenu";
import { tools } from "../app/components/tools/tools";
import { $ } from "src/app/components/tools/simpleJQ";

export const groupAnnotations = [annotationMenu_Select, new DDVAnnotationMenuErase(), annotationMenu_TextTypeWriter, new DDVAnnotationMenuTextBox('#112233', null, '#000'), new DDVAnnotationMenuInk('#112233'), new DDVAnnotationHighlightMode('#112233'), new DDVAnnotationUnderlineMode('#112233'), new DDVAnnotationStrikeoutMode('#112233')];
export const groupInsert = [insertMenu_Select, insertMenu_Stamp, insertMenu_OpenImageFile, insertMenu_sign];
export const groupShapes = [shapesMenu_Select, shapesMenu_Rectangle, new DDVSVGAnnotationMenuEllipse('#112233'), new DDVSVGAnnotationMenuPolygon('#112233'), new DDVAnnotationMenuPolyline('#112233'), new DDVAnnotationMenuLine('#112233')];

export let lastSelected = {
  viewer: '',
  annotation: annotationMenu_TextTypeWriter,
  insert: insertMenu_Stamp,
  shapes: shapesMenu_Rectangle
};

export let annotationMenuMap = {},
  stampImageMap = {}, inkSignatureImageMap = {};

export function initAllMenu() {
  tools.each(groupAnnotations, function (annotation) {
    let el = annotation.getEl();
    $('.ds-ddv-menugroup-Annotations').append(el);
    let buttonId = el.querySelector('.Button').id;
    if (buttonId) annotationMenuMap[buttonId] = annotation;
  });
  tools.each(groupInsert, function (annotation) {
    let el = annotation.getEl();
    $('.ds-ddv-menugroup-Insert').append(el);
    let buttonId = el.querySelector('.Button').id;
    if (buttonId) annotationMenuMap[buttonId] = annotation;
  });
  tools.each(groupShapes, function (annotation) {
    let el = annotation.getEl();
    $('.ds-ddv-menugroup-Shapes').append(el);
    let buttonId = el.querySelector('.Button').id;
    if (buttonId) annotationMenuMap[buttonId] = annotation;
  });
  
  $(".ds-ddv-footer-copyRightCurYear").html((new Date()).getFullYear());
}

export function getCurrentViewerGroups() {
  if (lastSelected.viewer == 'shapes') {
    return groupShapes;
  } else if (lastSelected.viewer == 'insert') {
    return groupInsert;
  } else if (lastSelected.viewer == 'annotation') {
    return groupAnnotations;
  }
  return [];
}
