
import { DDVAnnotationMenuSelect } from "../annotation/DDVAnnotationMenuSelect";
import { DDVAnnotationMenuTextTypewriter } from "../annotation/DDVAnnotationMenuTextTypewriter";

export const annotationMenu_Select = new DDVAnnotationMenuSelect();
export const annotationMenu_TextTypeWriter = new DDVAnnotationMenuTextTypewriter('#112233');