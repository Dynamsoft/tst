# Dynamsoft License Module

The Dynamsoft License module manages the licensing aspects of Dynamsoft SDKs based on the [DCV (Dynamsoft Capture Vision) architecture](https://www.dynamsoft.com/capture-vision/docs/core/architecture/index.html).