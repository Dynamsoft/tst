import Dynamsoft from 'dwt'

export const resourceRoot = ""
export const DDV_ImagePath = "images/pc"
export const timestamp = "202507081300"

export const environment = {
  Dynamsoft: {
    resourcesPath: 'Resources',
    dwtProductKey: 't01201wAAALY1hSsALNeAqHCEQleBKOZDLZ9j6Xs34H2a4LieDYiLnOVUIw7DAmMHcEsk13z5ix5FG0D8zgO8wYXFloycyujvcvTy58Ym5VU+nt089lN5vSkiF0fIqDM0wzIqB/V9OS4WPu1mAwzD35MWMGtitQKQYC0E',
    ddvProductKey: "t0114uQAAABP+StdhYql+Twxc5IBBWLPqmdMOioje8zgFqtH/fL8cEi52hoXYkove5IDiCveSpz8VJ4fT7kcT8VkYF/xUbGb/nhu57Kz83TgQeZevZdye01q2nYCsTHWSS5IkTWpMcBW1/1yjihiCquw8VCe0",
    ddvEngineResourcePath: resourceRoot + "DDV_Resources/dynamsoft-document-viewer@3.0.0/dist/engine/",

    serviceInstallerLocation: 'https://demo.dynamsoft.com/DWT/Resources/dist/19.1/',
    uploadTargetURL: 'https://demo.dynamsoft.com/sample-uploads/'
  },
  debug: false
}

export const Dynamsoft_Ref = Dynamsoft

interface IDDVExperimentsTool {
  ddvObject?: any
  editViewer?: any
  editFullViewer?: any
  thumbnailFullViewer?: any
  thumbnail?: any
  ignoreAnnotationDefaultStyleChanged?: boolean
}

export const DDVExperimentsTool : IDDVExperimentsTool = {
  ddvObject: undefined,
  editViewer: undefined,
  editFullViewer: undefined,
  thumbnailFullViewer: undefined,
  thumbnail: undefined,
  ignoreAnnotationDefaultStyleChanged: false
}

