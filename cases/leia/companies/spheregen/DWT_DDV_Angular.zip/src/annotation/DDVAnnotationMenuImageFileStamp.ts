import { tools } from "src/app/components/tools/tools";
import { DDVAnnotationMenuBase } from "./DDVAnnotationMenuBase";
import { $ } from "src/app/components/tools/simpleJQ";

export class DDVAnnotationMenuImageFileStamp extends DDVAnnotationMenuBase {

  constructor(c) {
    super(c, null, null);
  }
  _initData() {
    this.elData = "";
    this.elDataTooltip = "Image";
    this.iconClassName = "ddv-stamp-image";
    this.elDataLabel = "Image";
  }
  _createEl() {
    let el = document.createElement('div');
    el.style.width = "32px";
    el.style.margin = "0px 2px 0 6px";
    let elButton = document.createElement('button');
    elButton.className = 'Button';
    elButton.type = 'button';
    elButton.setAttribute('data-tooltip', 'Image');
    el.append(elButton);
    let elButtonInput = document.createElement('input');
    elButtonInput.className = "ddv-button-image-file";
    elButtonInput.accept = "image/png,image/jpeg,image/bmp";
    elButtonInput.type = "file";
    elButtonInput.id = tools.genUUID();
    elButton.append(elButtonInput);
    let elLabel = document.createElement('label');
    elLabel.className = "ddv-button-label-file";
    elLabel.htmlFor = elButtonInput.id;
    elButton.append(elLabel);
    let elButtonDiv = document.createElement('div');
    elButtonDiv.className = `ddv-button-icon ddv-button ${this.iconClassName}`;
    elLabel.append(elButtonDiv);
    this.el = el;
    this.extraData.elInput = elButtonInput;
  }
  bindClickEvent(selectedFilesCallbackFun, beforeClickCallbackFun) {
    let imageFile = $(this.extraData.elInput);
    imageFile.on("change", evt => {

      const f = evt.target;
      const { files } = f;

      if(files && files.length>0) {
        const blob = new Blob([files[0]], {
          type: files[0].type
        });

        selectedFilesCallbackFun(files, blob);
      }

      f.value = null;
      f.files = null;
    });

    imageFile.on("click", evt => {
      
      const f = evt.target;
      if (beforeClickCallbackFun) beforeClickCallbackFun();
      document.body.onfocus = () => {
        if (f.value.length) {}else {
          selectedFilesCallbackFun([], null);
        }
        document.body.onfocus = null;
      };
    });
  }
}