import { createSVGEl, createTag, DDVSVGAnnotationMenuBase } from "./DDVSVGAnnotationMenuBase";
import { $ } from "src/app/components/tools/simpleJQ";

export class DDVAnnotationStrikeoutMode extends DDVSVGAnnotationMenuBase {
  constructor(s) {
    super(s, null, 'transparent');
  }
  _initData() {
    this.elData = "strikeout";
    this.elDataTooltip = "Strikeout";
    this.iconClassName = "";
    this.elDataLabel = "Strikeout";
  }
  createSVG() {
    let svg = createSVGEl();
    svg.setAttribute('width', '25px');
    svg.setAttribute('height', '25px');
    let tag = createTag('polygon', {
      class: 'CustomShape',
      points: "10,48 10,52 87,52 87,48",
      style: `fill:${this.color};`
    });
    svg.append(tag);
    
    this.elButton.style.background = 'url("images/pc/strikeout.svg") border-box';
    this.elButtonDiv.style.width = '25px';

    return svg;
  }
  _resetStyle() {
    let _svg = $(this.elButtonDiv).find('.CustomShape');
    _svg.attr('style', `fill:${this.color};`);
  }
  setMenuColor(color) {
    let _svg = $(this.elButtonDiv).find('.CustomShape');
    _svg.attr('style', `fill:${color};`);
  }
  setMenuFill(f) {}
  setMenuStroke(c) {}
}