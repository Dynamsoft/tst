import { DDVAnnotationMenuBase } from "./DDVAnnotationMenuBase";
import { $ } from "src/app/components/tools/simpleJQ";

export class DDVAnnotationMenuSign extends DDVAnnotationMenuBase {
  constructor() {
    super(null, null);
    $(this.elButtonDiv).removeClass('ddv-button');
  }
  _initData() {
    this.elData = "signature";
    this.elDataTooltip = "Signature";
    this.iconClassName = "ddv-button-icon2 ddv-icon-signature";
    this.elDataLabel = "Signature";
  }
}
