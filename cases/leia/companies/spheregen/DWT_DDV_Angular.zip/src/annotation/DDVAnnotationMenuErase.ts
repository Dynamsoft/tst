import { DDVAnnotationMenuBase } from "./DDVAnnotationMenuBase";

export class DDVAnnotationMenuErase extends DDVAnnotationMenuBase {
  constructor() {
    super(null, null);
  }
  _initData() {
    this.elData = "erase";
    this.elDataTooltip = "Erase";
    this.iconClassName = "ddv-annot-eraser";
    this.elDataLabel = "Erase";
  }
}