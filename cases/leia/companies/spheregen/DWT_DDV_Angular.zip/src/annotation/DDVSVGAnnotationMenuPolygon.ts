import { createSVGEl, createTag, DDVSVGAnnotationMenuBase } from "./DDVSVGAnnotationMenuBase";

export class DDVSVGAnnotationMenuPolygon extends DDVSVGAnnotationMenuBase {
  constructor(s, f?) {
    super(s, f);
  }
  _initData() {
    this.elData = "polygon";
    this.elDataTooltip = "Polygon";
    this.iconClassName = "";
    this.elDataLabel = "Polygon";
  }
  createSVG() {
    let svg = createSVGEl();
    let tag = createTag('polygon', {
      class: 'CustomShape',
      points: "5.001605,40 20,95 80,95 95,40 50,5.001605",
      style: `fill:${this.fill};stroke:${this.color};stroke-width:4px`
    });
    svg.append(tag);
    return svg;
  }
}