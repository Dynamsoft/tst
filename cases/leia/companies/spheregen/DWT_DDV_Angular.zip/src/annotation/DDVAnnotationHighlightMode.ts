import { DDVAnnotationMenuBase } from "./DDVAnnotationMenuBase";

export class DDVAnnotationHighlightMode extends DDVAnnotationMenuBase {
  constructor(c) {
    super(c, null, null);
  }
  _initData() {
    this.elData = "highlight";
    this.elDataTooltip = "Highlight";
    this.iconClassName = "ddv-highlight-mode";
    this.elDataLabel = "Highlight";
  }
   getUpdateConfig() {
    let updateConfig = {
      defaultStyleConfig: {}
    };
    updateConfig.defaultStyleConfig[this.elData] = {
      background: this.color
    };
    return updateConfig;
  }
}