import { DDVAnnotationMenuBase } from "./DDVAnnotationMenuBase";

export class DDVAnnotationTextSelectionMode extends DDVAnnotationMenuBase {
  constructor() {
    super(null, null);
  }
  _initData() {
    this.elData = "textSelectionMode";
    this.elDataTooltip = "Text Selection Mode";
    this.elDataToolMode = "textSelection";
    this.iconClassName = "ddv-text-selection-mode";
    this.elDataLabel = "Text Selection";
  }
}