import { createSVGEl, createTag, DDVSVGAnnotationMenuBase } from "./DDVSVGAnnotationMenuBase";
import { $ } from "src/app/components/tools/simpleJQ";

export class DDVAnnotationUnderlineMode extends DDVSVGAnnotationMenuBase {
  constructor(s) {
    super(s, null, 'transparent');
  }
  _initData() {
    this.elData = "underline";
    this.elDataTooltip = "Underline";
    this.iconClassName = "";
    this.elDataLabel = "Underline";
  }
  createSVG() {
    let svg = createSVGEl();
    svg.setAttribute('width', '25px');
    svg.setAttribute('height', '25px');
    let tag = createTag('polygon', {
      class: 'CustomShape',
      points: "0.001605,90 0.001605,94 100,94 100,90",
      style: `fill:${this.color};`
    });
    svg.append(tag);
    
    this.elButton.style.background = 'url("images/pc/strikeout.svg") border-box';
    this.elButtonDiv.style.width = '25px';

    return svg;
  }
  _resetStyle() {
    let _svg = $(this.elButtonDiv).find('.CustomShape');
    _svg.attr('style', `fill:${this.color};`);
  }
  setMenuColor(color) {
    let _svg = $(this.elButtonDiv).find('.CustomShape');
    _svg.attr('style', `fill:${color};`);
  }
  setMenuFill(f) {}
  setMenuStroke(c) {}
}