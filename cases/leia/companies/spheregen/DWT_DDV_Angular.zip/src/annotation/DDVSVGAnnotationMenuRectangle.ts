import { createSVGEl, createTag, DDVSVGAnnotationMenuBase } from "./DDVSVGAnnotationMenuBase";

export class DDVSVGAnnotationMenuRectangle extends DDVSVGAnnotationMenuBase {
  constructor(s, f?) {
    super(s, f);
  }
  _initData() {
    this.elData = "rectangle";
    this.elDataTooltip = "Rectangle";
    this.iconClassName = "";
    this.elDataLabel = "Rectangle";
  }
  createSVG() {
    let svg = createSVGEl();
    let tag = createTag('polygon', {
      class: 'CustomShape',
      points: "5.001605,15 5.001605,91 95,91 95,15",
      style: `fill:${this.fill};stroke:${this.color};stroke-width:4px`
    });
    svg.append(tag);
    return svg;
  }
}