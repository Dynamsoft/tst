import { DDVAnnotationMenuBase } from "./DDVAnnotationMenuBase";

export class DDVAnnotationMenuSelect extends DDVAnnotationMenuBase {
  constructor() {
    super(null, null);
  }
  _initData() {
    this.elData = "select";
    this.elDataTooltip = "Select";
    this.iconClassName = "ddv-annot-select";
    this.elDataLabel = "Select";
  }
}