import { createSVGEl, createTag, DDVSVGAnnotationMenuBase } from "./DDVSVGAnnotationMenuBase";

export class DDVSVGAnnotationMenuEllipse extends DDVSVGAnnotationMenuBase {
  constructor(s, f?) {
    super(s, f);
  }
  _initData() {
    this.elData = "ellipse";
    this.elDataTooltip = "Ellipse";
    this.iconClassName = "";
    this.elDataLabel = "Ellipse";
  }
  createSVG() {
    let svg = createSVGEl();
    let tag = createTag('circle', {
      class: 'CustomShape',
      cx: "50",
      cy: "50",
      r: "40.001605",
      style: `fill:${this.fill};stroke:${this.color};stroke-width:4px`
    });
    svg.append(tag);
    return svg;
  }
}