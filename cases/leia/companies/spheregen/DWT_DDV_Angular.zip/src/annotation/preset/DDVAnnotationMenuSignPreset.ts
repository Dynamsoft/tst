import { DDV_ImagePath } from "../../globalObjects";
import { $ } from "src/app/components/tools/simpleJQ";

export class DDVAnnotationMenuSignPreset {

  wrapperEl;
  active;
  bBoundEvents;

  get isSignsEmpty() {
    let children = $(this.wrapperEl).find('.ddv-signs-container').children();
    return children.length == 0;
  }
  constructor() {
    let newWrapper = document.createElement('div');
    newWrapper.className = 'ds-icon-wrapper';
    let newEl = document.createElement('div');
    newEl.className = 'ds-stamp-sign-dropdown ds-collapse ddv-text-left';
    newEl.innerHTML = `<img src="${DDV_ImagePath}/blank.png" draggable="false" /><i class="ddv-demo-toolbar-icon-arrow"></i>`;
    newWrapper.append(newEl);
    let elDropDown = document.createElement('div');
    elDropDown.innerHTML = `
<div class="ddv-popup-dialog" style="display:none;left:-11px;top:29px">
    <div class="ddv-stamp-sign-overlay">
        <div class="ddv-overlay-panel">
          <div class="ddv-stamp-signs">
            <button class="ddv-sign-button-show-popui">Create New Signature</button>
            <div class="ddv-signs-container"></div>
          </div>
        </div>
    </div>
</div>
`;
    newWrapper.append(elDropDown);
    this.wrapperEl = newWrapper;
    this.active = false;
    this.bBoundEvents = false;
  }
  setActive() {
    $(this.wrapperEl).addClass('active');
    this.active = true;
  }
  setInActive() {
    $(this.wrapperEl).removeClass('active');
    this.active = false;
  }
  isActive() {
    return this.active;
  }
  bindEvents(funShowSignPopUI) {
    if (this.bBoundEvents) return;
    this.bBoundEvents = true;
    $('.ddv-sign-button-show-popui').on('click', function (evt) {
      evt.stopPropagation();
      if (funShowSignPopUI) funShowSignPopUI();
    });
    $(this.wrapperEl).on('click', evt => {
      evt.stopPropagation();
      $('.ddv-popup-dialog').toggle();
    });
  }
}