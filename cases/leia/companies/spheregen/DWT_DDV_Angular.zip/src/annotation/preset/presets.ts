import { tools } from "../../app/components/tools/tools";

import { DDVAnnotationMenuStampPreset } from "./DDVAnnotationMenuStampPreset";
import { DDVAnnotationMenuSignPreset } from "./DDVAnnotationMenuSignPreset";

import { DDVMenuAnnotationPreset } from "./DDVMenuAnnotationPreset";
import { DDVAnnotationHighlightMode } from "../DDVAnnotationHighlightMode";
import { DDVAnnotationMenuInk } from "../DDVAnnotationMenuInk";
import { DDVAnnotationMenuLine } from "../DDVAnnotationMenuLine";
import { DDVAnnotationMenuPolyline } from "../DDVAnnotationMenuPolyline";
import { DDVAnnotationMenuStamp } from "../DDVAnnotationMenuStamp";
import { DDVAnnotationMenuTextBox } from "../DDVAnnotationMenuTextBox";
import { DDVAnnotationStrikeoutMode } from "../DDVAnnotationStrikeoutMode";
import { DDVAnnotationUnderlineMode } from "../DDVAnnotationUnderlineMode";
import { DDVAnnotationMenuTextTypewriter } from "../DDVAnnotationMenuTextTypewriter";
import { DDVSVGAnnotationMenuEllipse } from "../DDVSVGAnnotationMenuEllipse";
import { DDVSVGAnnotationMenuPolygon } from "../DDVSVGAnnotationMenuPolygon";
import { DDVSVGAnnotationMenuRectangle } from "../DDVSVGAnnotationMenuRectangle";
import { DDVAnnotationMenuSign } from "../DDVAnnotationMenuSign";
import { groupAnnotations, groupInsert, groupShapes } from "../../menu/lastMenu";

let presetsSourceColorConfig = {
  textTypewriter: ['#F01314', '#07C37F', '#0E68F5', '#000'],
  textBox: ['#F01314', '#07C37F', '#0E68F5', '#000'],
  ink: ['#F01314', '#07C37F', '#0E68F5', '#000'],
  rectangle: ['#F01314', '#07C37F', '#0E68F5', '#000'],
  ellipse: ['#F01314', '#07C37F', '#0E68F5', '#000'],
  polygon: ['#F01314', '#07C37F', '#0E68F5', '#000'],
  polyline: ['#F01314', '#07C37F', '#0E68F5', '#000'],
  line: ['#F01314', '#07C37F', '#0E68F5', '#000'],
  highlight: ['#FD7C10', '#07C37F', '#0E68F5', '#000'],
  underline: ['#0E68F5', '#07C37F', '#F01314', '#000'],
  strikeout: ['#F01314', '#07C37F', '#0E68F5', '#000']
};

export class Presets {
  static createPresets(srcAnnotation) {
    if (srcAnnotation instanceof DDVAnnotationMenuStamp) {
      let preset = new DDVAnnotationMenuStampPreset();
      srcAnnotation.presetEls.push(preset);
      return;
    } else if (srcAnnotation instanceof DDVAnnotationMenuSign) {
      let preset = new DDVAnnotationMenuSignPreset();
      srcAnnotation.presetEls.push(preset);
      return;
    }
    let mode = srcAnnotation.elData;
    let bFirst = true;
    let modeColorConfigArray = presetsSourceColorConfig[mode];
    if (!modeColorConfigArray) {
      return;
    }
    tools.each(modeColorConfigArray, function (modeColor, index) {
      let newAnnotation;
      if (index === modeColorConfigArray.length - 1) {
        newAnnotation = Presets.createNew(srcAnnotation, modeColor, true);
      } else {
        newAnnotation = Presets.createNew(srcAnnotation, modeColor, false);
      }
      if (!newAnnotation) {
        return;
      }
      let preset = new DDVMenuAnnotationPreset(newAnnotation);
      srcAnnotation.presetEls.push(preset);
      if (bFirst) {
        preset.setActive();
        bFirst = false;
      }
    });
  }
  static createNew(srcAnnotation, newColorOrStroke, bFill) {
    if (srcAnnotation instanceof DDVSVGAnnotationMenuEllipse) {
       if(bFill)
        return new DDVSVGAnnotationMenuEllipse(newColorOrStroke, newColorOrStroke);
      else 
        return new DDVSVGAnnotationMenuEllipse(newColorOrStroke);
    }
    if (srcAnnotation instanceof DDVAnnotationMenuLine) {
      return new DDVAnnotationMenuLine(newColorOrStroke);
    }
    if (srcAnnotation instanceof DDVSVGAnnotationMenuPolygon) {
      if(bFill)
        return new DDVSVGAnnotationMenuPolygon(newColorOrStroke, newColorOrStroke);
      else
        return new DDVSVGAnnotationMenuPolygon(newColorOrStroke);
    }
    if (srcAnnotation instanceof DDVAnnotationMenuPolyline) {
      return new DDVAnnotationMenuPolyline(newColorOrStroke);
    }
    if (srcAnnotation instanceof DDVSVGAnnotationMenuRectangle) {
      if(bFill)
        return new DDVSVGAnnotationMenuRectangle(newColorOrStroke, newColorOrStroke);
      else 
        return new DDVSVGAnnotationMenuRectangle(newColorOrStroke);
    }
    if (srcAnnotation instanceof DDVAnnotationMenuInk) {
      return new DDVAnnotationMenuInk(newColorOrStroke);
    }
    if (srcAnnotation instanceof DDVAnnotationMenuTextTypewriter) {
      return new DDVAnnotationMenuTextTypewriter(newColorOrStroke);
    }
    if (srcAnnotation instanceof DDVAnnotationMenuTextBox) {
      let newTextBoxPreset = new DDVAnnotationMenuTextBox(newColorOrStroke, null, newColorOrStroke);
      newTextBoxPreset.setInActive();
      return newTextBoxPreset;
    }
    if (srcAnnotation instanceof DDVAnnotationHighlightMode) {
      return new DDVAnnotationHighlightMode(newColorOrStroke);
    }
    if (srcAnnotation instanceof DDVAnnotationUnderlineMode) {
      return new DDVAnnotationUnderlineMode(newColorOrStroke);
    }
    if (srcAnnotation instanceof DDVAnnotationStrikeoutMode) {
      return new DDVAnnotationStrikeoutMode(newColorOrStroke);
    }
    return null;
  }
}

// create presets
export function initMenuPresets() {
  tools.each(groupAnnotations, function (annotation) {
    Presets.createPresets(annotation);
  });
  tools.each(groupInsert, function (annotation) {
    Presets.createPresets(annotation);
  });
  tools.each(groupShapes, function (annotation) {
    Presets.createPresets(annotation);
  });
}
