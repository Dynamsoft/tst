import { $ } from "src/app/components/tools/simpleJQ";

export class DDVMenuAnnotationPreset {

    wrapperEl;
    annotation;
    active;
    bBoundEvents;

  constructor(newAnnotation) {
    let newEl = newAnnotation.getEl();
    let newWrapper = document.createElement('div');
    newWrapper.className = 'ds-icon-wrapper';
    newWrapper.append(newEl);
    let elDropDown = document.createElement('div');
    elDropDown.className = 'ds-icon-dropdown ds-collapse';
    elDropDown.innerHTML = '<i class="ddv-demo-toolbar-icon-arrow"></i>';
    newWrapper.append(elDropDown);
    this.wrapperEl = newWrapper;
    this.annotation = newAnnotation;
    this.active = false;
    this.bBoundEvents = false;
  }
  setActive() {
    this.annotation.setActive();
    $(this.wrapperEl).addClass('active');
    this.active = true;
  }
  setInActive() {
    this.annotation.setInActive();
    $(this.wrapperEl).removeClass('active');
    this.active = false;
  }
  isActive() {
    return this.active;
  }
  setBoundEvents() {
    this.bBoundEvents = true;
  }
  isBoundEvents() {
    return this.bBoundEvents;
  }
}