import { DDV_ImagePath } from "../../globalObjects";
import { $ } from "src/app/components/tools/simpleJQ";

export class DDVAnnotationMenuStampPreset {
  
  wrapperEl;
  active;
  bBoundEvents;

  constructor() {
    let newWrapper = document.createElement('div');
    newWrapper.className = 'ds-icon-wrapper';
    let newEl = document.createElement('div');
    newEl.className = 'ds-stamp-dropdown ds-collapse ddv-system-stamp';
    newEl.innerHTML = `<img data="SBDraft" src="${DDV_ImagePath}/DRAFT.png" draggable="false" /><i class="ddv-demo-toolbar-icon-arrow"></i>`;
    newWrapper.append(newEl);
    let elDropDown = document.createElement('div');
    elDropDown.innerHTML = `
<div class="ddv-popup-dialog" style="display:none;left:-11px;top:38px">
    <div class="ddv-stamp-overlay">
        <div class="ddv-overlay-panel">
          <div class="ddv-custom-operators">
            <button class="ddv-stamp-button-system active">System Stamp</button>
            <button class="ddv-stamp-button-custom">Custom Stamp</button>
          </div>
          <div class="ddv-system-stamps">
            <button class="ddv-system-stamp"><img draggable="false" data="SBDraft" src="${DDV_ImagePath}/DRAFT.png" /></button>
            <button class="ddv-system-stamp"><img draggable="false" data="SBConfidential" src="${DDV_ImagePath}/CONFIDENTIAL.png" /></button>
            <button class="ddv-system-stamp"><img draggable="false" data="SBVoid" src="${DDV_ImagePath}/VOID.png" /></button>
            <button class="ddv-system-stamp"><img draggable="false" data="SBNotApproved" src="${DDV_ImagePath}/NOT APPROVED.png" /></button>
            <button class="ddv-system-stamp"><img draggable="false" data="SBFinal" src="${DDV_ImagePath}/FINAL.png" /></button>
            <button class="ddv-system-stamp"><img draggable="false" data="SBApproved" src="${DDV_ImagePath}/APPROVED.png" /></button>
            <button class="ddv-system-stamp"><img draggable="false" data="SBCompleted" src="${DDV_ImagePath}/COMPLETED.png" /></button>
            <button class="ddv-system-stamp"><img draggable="false" data="SHWitness" src="${DDV_ImagePath}/stampWitness.png" /></button>
            <button class="ddv-system-stamp"><img draggable="false" data="SHAccepted" src="${DDV_ImagePath}/stampAccepted.png" /></button>
            <button class="ddv-system-stamp"><img draggable="false" data="SHInitialHere" src="${DDV_ImagePath}/stampInitalHere.png" /></button>
            <button class="ddv-system-stamp"><img draggable="false" data="SBRejected" src="${DDV_ImagePath}/stampRejected.png" /></button>
            <button class="ddv-system-stamp"><img draggable="false" data="SHSignHere" src="${DDV_ImagePath}/stampSignHere.png" /></button>
          </div>
          <div class="ddv-custom-stamps" style="display:none">
            <button class="ddv-stamp-button-show-popui">Create New Stamp</button>
            <div class="ddv-custom-stamps-container"></div>
          </div>
        </div>
    </div>
</div>    
`;
    newWrapper.append(elDropDown);
    this.wrapperEl = newWrapper;
    this.active = false;
    this.bBoundEvents = false;
  }
  setActive() {
    $(this.wrapperEl).addClass('active');
    this.active = true;
  }
  setInActive() {
    $(this.wrapperEl).removeClass('active');
    this.active = false;
  }
  isActive() {
    return this.active;
  }
  bindEvents(funShowStampPopUI) {
    if (this.bBoundEvents) return;
    this.bBoundEvents = true;
    $('.ddv-stamp-button-system').on('click', function (evt) {
      evt.stopPropagation();
      if ($('.ddv-stamp-button-system').hasClass('active')) return;
      $('.ddv-stamp-button-system').addClass('active');
      $('.ddv-stamp-button-custom').removeClass('active');
      $('.ddv-system-stamps').show();
      $('.ddv-custom-stamps').hide();
    });
    $('.ddv-stamp-button-custom').on('click', function (evt) {
      evt.stopPropagation();
      if ($('.ddv-stamp-button-custom').hasClass('active')) return;
      $('.ddv-stamp-button-system').removeClass('active');
      $('.ddv-stamp-button-custom').addClass('active');
      $('.ddv-system-stamps').hide();
      $('.ddv-custom-stamps').show();
    });
    $('.ddv-stamp-button-show-popui').on('click', function (evt) {
      evt.stopPropagation();
      if (funShowStampPopUI) funShowStampPopUI();
    });
    $(this.wrapperEl).on('click', evt => {
      evt.stopPropagation();
      $('.ddv-popup-dialog').toggle();
    });
  }
}
