import { createTag, DDVSVGAnnotationMenuBase } from "./DDVSVGAnnotationMenuBase";

export class DDVAnnotationMenuTextBox extends DDVSVGAnnotationMenuBase {

  constructor(c, f, strokeColor) {
    super(c, f, strokeColor);
  }
  
  _initData() {
    this.elData = "textBox";
    this.elDataTooltip = "TextBox";
    this.iconClassName = "";
    this.elDataLabel = "TextBox";
    this.extraData.rect = null;
    this.extraData.c1 = null;
    this.extraData.c2 = null;
    this.extraData.c3 = null;
    this.extraData.c4 = null;
    this.extraData.textEl = null;
  }
  createSVG() {
    const svg = createTag('svg', {
      'version': '1.1',
      'viewBox': '0 0 1024 1024',
      'width': '25px',
      'height': '25px'
    });

    const _stroke = this.strokeColor ? this.strokeColor : '#000';
    const _fill = this.fill || 'transparent';

    const _rect = createTag('rect', {
      'x': '105',
      'y': '105',
      'width': '815',
      'height': '815',
      'stroke-width': '20',
      'style': `fill:${_fill};stroke:${_stroke};`
    });
    svg.append(_rect);

    this.extraData.rect = _rect;
    
    const c1 = createTag('circle', {
      'cx': '105',
      'cy': '105',
      'r': '80',
      'stroke-width': '20',
      'style': `fill:#F1F2F3;stroke:${_stroke};`
    });
    this.extraData.c1 = c1;
    svg.append(c1);

    const c2 = createTag('circle', {
      'cx': '915',
      'cy': '105',
      'r': '80',
      'stroke-width': '20',
      'style': `fill:#F1F2F3;stroke:${_stroke};`
    });
    this.extraData.c2 = c2;
    svg.append(c2);

    const c3 = createTag('circle', {
      'cx': '915',
      'cy': '915',
      'r': '80',
      'stroke-width': '20',
      'style': `fill:#F1F2F3;stroke:${_stroke};`
    });
    this.extraData.c3 = c3;
    svg.append(c3);

    const c4 = createTag('circle', {
      'cx': '105',
      'cy': '915',
      'r': '80',
      'stroke-width': '20',
      'style': `fill:#F1F2F3;stroke:${_stroke};`
    });
    this.extraData.c4 = c4;
    svg.append(c4);

    const _path = createTag('path', {
      d: "M703 259H320c-24 0-43 19-43 43v63c0 12 9 22 22 22s22-9 22-22L320 304H489v422h-41c-12 0-22 9-22 22s9 22 22 22h127c12 0 22-9 22-22s-9-22-22-22H534V303h168v63c0 12 9 22 22 22s22-9 22-22V303c0-24-19-43-43-43z",
      style: `fill:${this.color};`
    });
    this.extraData.textEl = _path;
    svg.append(_path);
    
    this.elButtonDiv.style.width = '25px';

    return svg;
  }
  getUpdateConfig() {
    let updateConfig = {
      defaultStyleConfig: {}
    };
    updateConfig.defaultStyleConfig[this.elData] = {
      textContent: {
        color: this.color
      }
    };
    
    updateConfig.defaultStyleConfig[this.elData].borderColor = this.strokeColor || '#000';
    let _fill = this.fill;
    if (_fill == 'none' || _fill == 'transparent') _fill = '';
    updateConfig.defaultStyleConfig[this.elData].background = _fill;

    return updateConfig;
  }
  
  setMenuColor(color) {
    if(this.extraData.textEl) {
      this.extraData.textEl.style.fill = color;
    }
  }
  setMenuFill(fill) {
    if(this.extraData.rect) {
      let _fill = fill;
      if (_fill == '' || _fill == 'none') _fill = 'transparent';
      this.extraData.rect.style.fill = _fill;
    }
  }
  setMenuStroke(strokeColor) {
    const _stroke = strokeColor ? strokeColor : '#000';
    if(this.extraData.rect) this.extraData.rect.style.stroke = _stroke;
    if(this.extraData.c1) this.extraData.c1.style.stroke = _stroke;
    if(this.extraData.c2) this.extraData.c2.style.stroke = _stroke;
    if(this.extraData.c3) this.extraData.c3.style.stroke = _stroke;
    if(this.extraData.c4) this.extraData.c4.style.stroke = _stroke;
  }

  _resetStyle() {
    this.setMenuColor(this.color);
    this.setMenuFill(this.fill);
    this.setMenuStroke(this.strokeColor);
  }
  setActive() {
    super.setActive();
    const _fill = '#D7D8D9';
    if(this.extraData.c1) this.extraData.c1.style.fill = _fill;
    if(this.extraData.c2) this.extraData.c2.style.fill = _fill;
    if(this.extraData.c3) this.extraData.c3.style.fill = _fill;
    if(this.extraData.c4) this.extraData.c4.style.fill = _fill;
  }
  setInActive() {
    super.setInActive();
    const _fill = '#FFFFFF';
    if(this.extraData.c1) this.extraData.c1.style.fill = _fill;
    if(this.extraData.c2) this.extraData.c2.style.fill = _fill;
    if(this.extraData.c3) this.extraData.c3.style.fill = _fill;
    if(this.extraData.c4) this.extraData.c4.style.fill = _fill;
  }
}