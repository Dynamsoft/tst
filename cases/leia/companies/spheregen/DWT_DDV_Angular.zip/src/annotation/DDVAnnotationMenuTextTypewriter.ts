import { DDVAnnotationMenuBase } from "./DDVAnnotationMenuBase";

export class DDVAnnotationMenuTextTypewriter extends DDVAnnotationMenuBase {
  constructor(c) {
    super(c, null);
  }
  _initData() {
    this.elData = "textTypewriter";
    this.elDataTooltip = "Typewriter";
    this.iconClassName = "ddv-typewriter";
    this.elDataLabel = "Typewriter";
  }
  getUpdateConfig() {
    let updateConfig = {
      defaultStyleConfig: {}
    };
    updateConfig.defaultStyleConfig[this.elData] = {
      textContent: {
        color: this.color
      }
    };
    return updateConfig;
  }
}