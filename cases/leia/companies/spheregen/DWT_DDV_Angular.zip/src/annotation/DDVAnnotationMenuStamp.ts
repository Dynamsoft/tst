import { DDVAnnotationMenuBase } from "./DDVAnnotationMenuBase";

export class DDVAnnotationMenuStamp extends DDVAnnotationMenuBase {
  constructor() {
    super(null, null);
  }
  _initData() {
    this.elData = "stamp";
    this.elDataTooltip = "Stamp";
    this.iconClassName = "ddv-stamp-icon";
    this.elDataLabel = "Stamp";
  }
}