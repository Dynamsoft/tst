import { DDVAnnotationMenuBase } from "./DDVAnnotationMenuBase";

export class DDVAnnotationMenuPolyline extends DDVAnnotationMenuBase {
  constructor(s, f?) {
    super(s, f);
  }
  _initData() {
    this.elData = "polyline";
    this.elDataTooltip = "Polyline";
    this.iconClassName = "ddv-polyline";
    this.elDataLabel = "Polyline";
  }
}