import { DDVAnnotationMenuBase } from "./DDVAnnotationMenuBase";

export class DDVAnnotationMenuInk extends DDVAnnotationMenuBase {
  constructor(c) {
    super(c, null);
  }
  _initData() {
    this.elData = "ink";
    this.elDataTooltip = "Ink";
    this.iconClassName = "ddv-ink";
    this.elDataLabel = "Ink";
  }
}