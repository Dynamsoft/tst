import { DDVAnnotationMenuBase } from "./DDVAnnotationMenuBase";
import { $ } from "src/app/components/tools/simpleJQ";

export class DDVSVGAnnotationMenuBase extends DDVAnnotationMenuBase {
  constructor(c, f, strokeColor?) {
    super(c,f, strokeColor);
  }
  _createEl() {
    this.iconClassName = "";
    super._createEl();
    if (this.elButtonDiv) {
      let _svg = this.createSVG();
      if(_svg)
        this.elButtonDiv.append(_svg);
    }
  }
  _resetStyle() {
    let _svg = $(this.elButtonDiv).find('.CustomShape');
    _svg.css('stroke', this.color);
    _svg.css('fill', this.fill);
  }
  createSVG(): any {
    return null;
  }
  getUpdateConfig() {
    let updateConfig = {
      defaultStyleConfig: {}
    };
    updateConfig.defaultStyleConfig[this.elData] = {
      borderColor: this.color
    };
    let _fill = this.fill;
    if (_fill == 'none' || _fill == 'transparent') _fill = '';
    updateConfig.defaultStyleConfig[this.elData].background = _fill;
    return updateConfig;
  }
  setMenuColor(color) {
    let _svg = $(this.elButtonDiv).find('.CustomShape');
    _svg.css('stroke', color);
  }
  setMenuFill(fill) {
    let _svg = $(this.elButtonDiv).find('.CustomShape'),
      _fill = fill;
    if (_fill == 'none' || _fill == 'transparent') _fill = '';
    _svg.css('fill', _fill);
  }
}
export function createSVGEl() {
  const svg = document.createElementNS("http://www.w3.org/2000/svg", 'svg');
  svg.setAttribute('version', '1.1');
  svg.setAttribute('viewBox', '0 0 100 100');
  svg.setAttribute('width', '20px');
  svg.setAttribute('height', '20px');
  return svg;
}
export function createTag(tag, attrArr) {
  var Tag = document.createElementNS("http://www.w3.org/2000/svg", tag);
  for (var attr in attrArr) {
    if (attr == 'content') {
      Tag.innerHTML = attrArr[attr];
      continue;
    }
    Tag.setAttribute(attr, attrArr[attr]);
  }
  return Tag;
}