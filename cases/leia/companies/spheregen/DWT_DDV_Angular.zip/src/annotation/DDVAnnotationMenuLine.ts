import { DDVAnnotationMenuBase } from "./DDVAnnotationMenuBase";

export class DDVAnnotationMenuLine extends DDVAnnotationMenuBase {
  constructor(s, f?) {
    super(s, f);
  }
  _initData() {
    this.elData = "line";
    this.elDataTooltip = "Line";
    this.iconClassName = "ddv-line";
    this.elDataLabel = "Line";
  }
}