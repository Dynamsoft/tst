import { tools } from "../app/components/tools/tools";
import { $ } from "src/app/components/tools/simpleJQ";

export class DDVAnnotationMenuBase {
    
    elDataToolMode;
    color;
    fill;
    strokeColor;
    presetEls;

    el;
    elButton;
    elButtonDiv;

    elData;
    elDataTooltip;
    iconClassName;
    elDataLabel;

    extraData;

  constructor(c, f?, strokeColor?) {
    this.elDataToolMode = "annotation";
    this.extraData={};
    this._initData();
    this.color = c || '#000';
    this.fill = f || '';
    this.strokeColor = strokeColor || '#000';
    this.presetEls = [];
    this._createEl();
    this._resetStyle();
  }
  _initData() {
    this.elData = "";
    this.elDataTooltip = "";
    this.iconClassName = "";
    this.elDataLabel = "";
  }
  _createEl() {
    let el = document.createElement('div');
    el.setAttribute('data-element', this.elData);
    el.setAttribute('data-tooltip', this.elDataTooltip);
    el.setAttribute('data-toolMode', this.elDataToolMode);
    //el.setAttribute('data-label', this.elDataLabel);
    el.className = 'tool-group-button';
    let elButton = document.createElement('button');
    elButton.setAttribute('data-element', this.elData);
    elButton.className = 'Button';
    elButton.type = 'button';
    elButton.id = tools.genUUID();
    el.append(elButton);
    let elButtonDiv = document.createElement('div');
    elButtonDiv.className = `ddv-button-icon ddv-button ${this.iconClassName}`;
    //let elLabel = document.createElement('span');
    //elLabel.textContent  = this.elDataLabel;
    //elButtonDiv.append(elLabel);
    elButton.append(elButtonDiv);
    this.el = el;
    this.elButton = elButton;
    this.elButtonDiv = elButtonDiv;
  }
  _resetStyle() {
    if (this.elButtonDiv) {
      this.elButtonDiv.style.color = this.color;
    }
  }
  getEl() {
    return this.el;
  }
  getElButton() {
    return this.elButton;
  }
  getElButtonDiv() {
    return this.elButtonDiv;
  }
  getElData() {
    return this.elData;
  }
  getElDataToolMode() {
    return this.elDataToolMode;
  }
  getUpdateConfig() {
    let updateConfig = {
      defaultStyleConfig: {}
    };
    updateConfig.defaultStyleConfig[this.elData] = {
      borderColor: this.color
    };
    return updateConfig;
  }
  setActive() {
    // add active
    $(this.elButton).addClass('active');
    $(this.el).addClass('active');
  }
  setInActive() {
    // remove active
    $(this.elButton).removeClass('active');
    $(this.el).removeClass('active');
    this._resetStyle();
  }
  setMenuColor(color) {
    if (this.elButtonDiv) {
      this.elButtonDiv.style.color = color;
    }
  }
  setMenuFill(fill) {}
  setMenuStroke(strokeColor) {}
}